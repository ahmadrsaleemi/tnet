const Flatefare = require('../../models/Flatefares');
const User = require('../../models/user');

module.exports = {
  Flatefares: async (args,req) => {
    try {
      
      const flatefares = await Flatefare.find().sort( { _id:1 } );;
      return flatefares;
    } catch (err) {
      throw err;
    }
  },
  destroyFlatefare: async (args) => {
    //return args;
    console.log(args);
    try {
      let  flatefares =[];
      flatefares = await Flatefare.findById({_id:args.recordID}) ;
      
      await Flatefare.deleteOne({_id:args.recordID});
      
      console.log(flatefares);
     
      return flatefares;
    
    } catch (err) {
      throw err;
    }
  },
  Flatefare : async (args, req) => {
    try{
    const flatefares = await Flatefare.findById({_id:args.flatefareId}) ;
    return flatefares;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createFlatefare: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    console.log(args);

    const flatefare = new Flatefare({
      name: args.flatefareInput.name,
      startday: args.flatefareInput.startday,
      endday: args.flatefareInput.endday,
      starthoure: args.flatefareInput.starthoure,
      endhoure: args.flatefareInput.endhoure,
      active: args.flatefareInput.active,
      allday: args.flatefareInput.allday,
      date:"2020-02-03T10:41:20.673Z",
      creator: '5e2c16b13e911532b4c22f75',
      details:[]
    });

    let createdFlatefare;
    try {
      const result = await flatefare.save();
      createdFlatefare = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdFlatefare;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateFlatefare : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }

    try {
      const result = await Flatefare.update( {'_id': args.flatefareInput.id},
        { $set:{
          name: args.flatefareInput.name,
          startday:args.flatefareInput.startday,
          endday:args.flatefareInput.endday,
          starthoure:args.flatefareInput.starthoure,
          endhoure:args.flatefareInput.endhoure,
          active:args.flatefareInput.active,
          allday: args.flatefareInput.allday
        } });

      const flatefares = await Flatefare.find();
      return flatefares;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  filterFlatefare : async (args) => {
    console.log(args)
    try{
      const flatefares = await Flatefare.find({"name": {"$regex":args.name, "$options": "i"}});
      return flatefares;
    }catch(err){
      console.log(err)
    }
  }
};
