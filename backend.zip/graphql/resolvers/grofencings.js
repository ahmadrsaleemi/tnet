const Geofencing = require('../../models/Geofencings');
const User = require('../../models/user');

module.exports = {
Geofencings: async () => {
    try {
      const geofencings = await Geofencing.find({active:true});
      return geofencings;
    } catch (err) {
      throw err;
    }
  },
  destroyGeofencing: async (args) => {
    //return args;
    console.log(args);
    try {
      let  geofencings =[];
      geofencings = await Geofencing.findById({_id:args.recordID}) ;
      await Geofencing.update({'_id': args.recordID},
        {$set:{
          'active': false
      }
      },{multi:true});

      // await Geofencing.deleteOne({_id:args.recordID});    

      return geofencings;
    
    } catch (err) {
      throw err;
    }
  },
  Geofencing : async (args, req) => {
    try{
    const geofencings = await Geofencing.findById({_id:args.geofencingId}) ;
    return geofencings;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createGeofencing: async (args, req) => {
    console.log(args);
    try {
      const existingTitle = await Geofencing.find({title:args.geofencingInput.title})
      console.log(existingTitle);
      const geofencing = new Geofencing({
        title:args.geofencingInput.title,
        country: args.geofencingInput.country,
        city: args.geofencingInput.city,
        area:args.geofencingInput.area,
        poi:args.geofencingInput.poi,
        geofencing:args.geofencingInput.geofencing,
        coordinates:args.geofencingInput.coordinates,
        iata:args.geofencingInput.iata,
        active:true,
        creator: '5e2c16b13e911532b4c22f75'
      });
      if(existingTitle.length > 0){
        await Geofencing.update({'title': args.geofencingInput.title},
          {$set:{
            'active': true
        }
        },{multi:true});

        var recordsToSend = [];
        for(var i=0; i< existingTitle.length; i++){
          recordsToSend = existingTitle[i];
        }
        return recordsToSend;
      }
      else{
        
        let createdGeofencing;
        const result = await geofencing.save();
        createdGeofencing = result;
        return createdGeofencing;
      } 
      
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateGeofencing : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }

    try {
      const result = await Geofencing.update({'_id': args.geofencingInput.id},
        {$set:{
        'country': args.geofencingInput.country,
        "city":args.geofencingInput.city,
        "area":args.geofencingInput.area,
        "poi":args.geofencingInput.poi,
        "geofencing":args.geofencingInput.geofencing,
        "iata":args.geofencingInput.iata
      }
      },{multi:true});

      const geofencings = await Geofencing.find();
      return geofencings;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  SearchGeofencing : async (args,req) => {
    console.log(args)
    try
    {

      let searchresult =[];
      var filter = {};

      if (args.SearchGeofencingInput.aname != '')
          filter.area =args.SearchGeofencingInput.aname;

      if (args.SearchGeofencingInput.country != '')
          filter.country =args.SearchGeofencingInput.country;
        
      if (args.SearchGeofencingInput.city != '')
          filter.city =args.SearchGeofencingInput.city;
      
      if (args.SearchGeofencingInput.poi != '')
          filter.poi =args.SearchGeofencingInput.poi;
      
      
      searchresult = await Geofencing.find(filter);
      
      
    return searchresult;
    } catch(err){
      console.log(err);
      throw err;
    }
  },
};
