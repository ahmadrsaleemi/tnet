const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = require('../../models/user');

module.exports = {
  Users: async (args) => {
    try{
        let users = User.find();
        return users;
      }catch(err){
        throw err;
      }
  },
  User : async (args) => {
    try{
      const users = await User.findById({_id:args.UserId}) ;
      return users;
      }
      catch (err) {
        console.log(err);
        throw err;
      }
  },
  createUser: async args => {
    try {
      const existingUser = await User.findOne({ email: args.userInput.email });
      if (existingUser) {
        throw new Error('User exists already.');
      }
      const hashedPassword = await bcrypt.hash(args.userInput.password, 12);

      const user = new User({
        email: args.userInput.email,
        password: hashedPassword,
        type:args.userInput.type
      });

      const result = await user.save();

      return { ...result._doc, password: null, _id: result.id };
    } catch (err) {
      throw err;
    }
  },
  login: async ({ email, password }) => {
    const user = await User.findOne({ email: email });
    if (!user) {
      throw new Error('User does not exist!');
    }
    const isEqual = await bcrypt.compare(password, user.password);
    if (!isEqual) {
      throw new Error('Password is incorrect!');
    }
    // const token = jwt.sign(
    //   { userId: user.id, email: user.email },
    //   'somesupersecretkey',
    //   {
    //     expiresIn : '1h'
    //   }
    // );

    const token = jwt.sign(
      { userId: user.id, email: user.email },
      'somesupersecretkey'
    );
    return { type:user.type,userId: user.id, token: token, tokenExpiration: 1 };
  },
  destroyUser : async(args) => {
    //return args;
    console.log(args);
    try {
      let  users =[];
      users = await User.findById({_id:args.recordID}) ;
      
      await User.deleteOne({_id:args.recordID});
      
      console.log(users);
     
      return users;
    
    } catch (err) {
      throw err;
    }
  },
  updateUser : async(args) => {
       // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    console.log(args);
    try {
      const hashedPassword = await bcrypt.hash(args.userInput.password, 12);
      await User.updateMany({'_id': args.userInput._id},
        {$set:{'email': args.userInput.email,'password':hashedPassword,
        'type':args.userInput.type
      }
      },{multi:true});

      const users = await User.find();
      return users;
    } catch (err) {
      console.log(err);
      throw err;
    }
  }
};
