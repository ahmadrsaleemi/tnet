const Meteredfare = require('../../models/Meteredfare');
const User = require('../../models/user');

module.exports = {

  Meteredfares: async () => {
    try {
      const meteredfares = await Meteredfare.find();
      return meteredfares;
    } catch (err) {
      throw err;
    }
  },
  destroyMeteredfare: async (args) => {
    //return args;
    console.log(args);
    try {
      let  meteredfares =[];
      meteredfares = await Meteredfare.findById({_id:args.recordID}) ;
      
      await Meteredfare.deleteOne({_id:args.recordID});
      
      console.log(meteredfares);
     
      return meteredfares;
    
    } catch (err) {
      throw err;
    }
  },

  Meteredfare : async (args, req) => {
    try{
    const meteredfares = await Meteredfare.findById({_id:args.MeteredfareId}) ;
    return meteredfares;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createMeteredfare: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    // console.log(args.flatefareInput.name);
    const meteredfare = new Meteredfare({
      name: args.MeteredfareInput.name,
      startday: args.MeteredfareInput.startday,
      endday: args.MeteredfareInput.endday,
      starthoure: args.MeteredfareInput.starthoure,
      endhoure: args.MeteredfareInput.endhoure,
      active: args.MeteredfareInput.active,
      allday: args.MeteredfareInput.allday,
      date:"2020-02-03T10:41:20.673Z",
      creator: '5e2c16b13e911532b4c22f75',
      distancebased:[],
      timebased:[]
    });

    let createdmeteredfare;
    try {
      const result = await meteredfare.save();
      createdmeteredfare = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdmeteredfare;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateMeteredfare : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }

    try {
      const result = await Meteredfare.update( {'_id': args.MeteredfareInput.id},
      {$set:{
        'name': args.MeteredfareInput.name,
        "startday":args.MeteredfareInput.startday,
        "endday":args.MeteredfareInput.endday,
        "starthoure":args.MeteredfareInput.starthoure,
        "endhoure":args.MeteredfareInput.endhoure,
        "active":args.MeteredfareInput.active,
        "allday": args.MeteredfareInput.allday
      }
      },{multi:true});

      const meteredfares = await Meteredfare.find();
      return meteredfares;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  addMeteredfaredetail : async(args) => {

    console.log(args.MeteredfareTDbasedInput.meteredfare);
    const meteredfares = await Meteredfare.findById({_id:args.MeteredfareTDbasedInput.meteredfare}) ;
    
    if (!meteredfares) {
      throw new Error('User not found.');
    }
    if(args.MeteredfareTDbasedInput.type == "distance"){
      meteredfares.distancebased.push(args.MeteredfareTDbasedInput);
      await meteredfares.save();
      const meteredfaredetails = args.MeteredfareTDbasedInput
      return meteredfaredetails;
    }

    if(args.MeteredfareTDbasedInput.type == "time"){
      console.log("time");
      meteredfares.timebased.push(args.MeteredfareTDbasedInput);
      await meteredfares.save();
      const meteredfaredetails = args.MeteredfareTDbasedInput
      return meteredfaredetails;
    }
    
  }
  ,
  deleteMeteredfaredetail : async(args) => {
    console.log(args.meteredfare,args.type,args.index);

    const meteredfares = await Meteredfare.findById({_id:args.meteredfare});
    if (!meteredfares) {
      throw new Error('Metered Fare not found.');
    }
    if(args.type == "distance"){
        for(var i=0 ;i < meteredfares.distancebased.length;i++){
            if(meteredfares.distancebased[i]._id == args.index){
              meteredfares.distancebased.splice(i,1);
            }
        }
        await meteredfares.save();
    }
    else if(args.type == "time"){
        for(var i=0 ;i < meteredfares.timebased.length;i++){
            if(meteredfares.timebased[i]._id == args.index){
              meteredfares.timebased.splice(i,1);
            }
        }
        await meteredfares.save();
    }
    return meteredfares;
  },
  editMeteredfaredetail:async (args) => {
    console.log(args.meteredfare,args.type,args.index);
    const meteredfares = await Meteredfare.findById({_id:args.meteredfare});

    var name = meteredfares.name;
    var dort = '';
    var startupfee='';
    var sp=[];
    var cp = [];
    dataToSend = [];
    if(args.type == "distance"){
      for(var i=0 ;i < meteredfares.distancebased.length;i++){
          if(meteredfares.distancebased[i]._id == args.index){
            dort = meteredfares.distancebased[i].distance;
            startupfee = meteredfares.distancebased[i].startup;
            sp = meteredfares.distancebased[i].spprice;
            cp = meteredfares.distancebased[i].cusprice;
          }
      }

      dataToSend = {
        name,
        dort,
        startupfee,
        sp,
        cp
      }
  }
  else if(args.type == "time"){
      for(var i=0 ;i < meteredfares.timebased.length;i++){
        if(meteredfares.timebased[i]._id == args.index){
          dort = meteredfares.timebased[i].distance;
          startupfee = meteredfares.timebased[i].startup;
          sp = meteredfares.timebased[i].spprice;
          cp = meteredfares.timebased[i].cusprice;
        }
    }

    dataToSend = {
      name,
      dort,
      startupfee,
      sp,
      cp
    }
  }
  console.log(dataToSend,"dataToSend");

  return dataToSend;
  },
  updateMeteredfaredetail : async (args) => {
    console.log(args);
    // {
    //   "meteredfare":'5e6b776bf8807035a885603a',
    //   "type":'distance',
    //   "index": '1584708947398',
    //   "spprice": [ 'Taxi-------100', 'Premium-------100', 'Mini Van-------100' ],
    //   "cusprice": [ 'Taxi-------300', 'Premium-------300', 'Mini Van-------300' ],
    //   "distance": '200-300',
    //   "startupfee": '200',
    //   "name":'MF 101'
    // }
    const newData = {
      _id:args.index,
      meteredfare:args.meteredfare,
      distance:args.distance,
      startup:args.startupfee,
      spprice:args.spprice,
      cusprice:args.cusprice,
      type:args.type
    }

    const meteredfares = await Meteredfare.findById({_id:args.meteredfare});
    if(args.type == "distance"){
      for(var i=0 ;i < meteredfares.distancebased.length;i++){
          if(meteredfares.distancebased[i]._id == args.index){
             meteredfares.distancebased.splice(i,1);
            
          }
      }
      
      meteredfares.distancebased.push(newData);
      meteredfares.save();
      return "success";
  }
  else if(args.type == "time"){
    console.log("i am in time based",args.index)
        for(var i=0 ;i < meteredfares.timebased.length;i++){
          if(meteredfares.timebased[i]._id == args.index){
              meteredfares.timebased.splice(i,1);
          }
      }

      meteredfares.timebased.push(newData);
      meteredfares.save();
      return "success";
    }
    else
    return "failed";
    
  },

  filterMeteredfare : async (args) => {
    console.log(args)
    try{
      const meteredfares = await Meteredfare.find({"name": {"$regex":args.name, "$options": "i"}});
      return meteredfares;
    }catch(err){
      console.log(err)
    }
  }
};
