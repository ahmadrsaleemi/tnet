const authResolver = require('./auth');
const eventsResolver = require('./events');
const bookingResolver = require('./bookings');
const segmentResolver = require('./segments');
const attributeResolver = require('./attributes');
const geofencingResolver = require('./grofencings');
const flatefareResolver = require('./flatefares');
const flatefaredetailsResolver = require('./flatefaredetails');
const meteredfare = require('./meteredfares');
const attributeGroupResolver = require('./attributegroups');
const priceListResolver = require('./pricelist');
const SPManagementResolver = require('./Spmanagement')
const rootResolver = {
  ...authResolver,
  ...eventsResolver,
  ...bookingResolver,
  ...segmentResolver,
  ...attributeResolver,
  ...geofencingResolver,
  ...flatefareResolver,
  ...flatefaredetailsResolver,
  ...meteredfare,
  ...attributeGroupResolver,
  ...priceListResolver,
  ...SPManagementResolver
};

module.exports = rootResolver;
