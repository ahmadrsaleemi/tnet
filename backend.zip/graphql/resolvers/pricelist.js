const Pricelist = require('../../models/pricelist');
const User = require('../../models/user');
const Flatefare = require('../../models/Flatefares')
const Meteredfare = require('../../models/Meteredfare')
const AttributeGroup = require('../../models/Attributegroup')


module.exports = {
Pricelists: async () => {
    try {
      const pricelists = await Pricelist.find();
      console.log(pricelists);
      return pricelists;
    } catch (err) {
      throw err;
    }
  },
  destroyPricelist: async (args) => {
    //return args;
    console.log(args);
    try {
      let  pricelists =[];
      pricelists = await Pricelist.findById({_id:args.recordID}) ;
      
      await Pricelist.deleteOne({_id:args.recordID});
      
      console.log(pricelists);
     
      return pricelists;
    
    } catch (err) {
      throw err;
    }
  },
  Pricelist : async (args, req) => {
    try{
      console.log(args)

    const pricelists = await Pricelist.findById({_id:args.pricelistId}) ;

       let flatefare = [];
       for(var ff = 0 ; ff < pricelists.flatefare.length;ff++){
         const faltfares = await Flatefare.find({"_id":pricelists.flatefare[ff]});

          for(var i = 0 ; i < faltfares.length;i++){
            flatefare.push(faltfares[i].name+'-------'+faltfares[i]._id);
          }
       }
      let meteredfare = [];
      for(var mm = 0 ; mm < pricelists.meteredfare.length;mm++){
        const meteredfares = await Meteredfare.find({"_id":pricelists.meteredfare[mm]});

         for(var i = 0 ; i < meteredfares.length;i++){
          meteredfare.push(meteredfares[i].name+'-------'+meteredfares[i]._id);
         }
      }

      let attribute = [];

      for(var ag = 0 ; ag < pricelists.attributegroup.length;ag++){

        const attributes = await AttributeGroup.find({"_id":pricelists.attributegroup[ag]});

         for(var i = 0 ; i < attributes.length;i++){
          attribute.push(attributes[i].name+'-------'+attributes[i]._id);
         }
      }


     return {
      "_id":pricelists._id,
      "name": pricelists.name,
      "active": pricelists.active,
      "flatefare":flatefare,
      "meteredfare": meteredfare,
      "attributegroup":attribute
    };
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createPricelist: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    const pricelist = new Pricelist({
      name: args.PricelistInput.name,
      flatefare: args.PricelistInput.flatefare,
      meteredfare: args.PricelistInput.meteredfare,
      attributegroup: args.PricelistInput.attributegroup,
      active: args.PricelistInput.active,
      creator: '5e2c16b13e911532b4c22f75'
    });
    let createdPricelist;
    try {
      const result = await pricelist.save();
      createdPricelist = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdPricelist;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updatePricelist : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }

    try {
      console.log()
      const result = await Pricelist.updateOne({'_id': args.PricelistInput._id},
        {$set:{
          "name": args.PricelistInput.name,
          "flatefare": args.PricelistInput.flatefare,
          "meteredfare": args.PricelistInput.meteredfare,
          "attributegroup": args.PricelistInput.attributegroup,
          "active": args.PricelistInput.active,
      }
      },{multi:true});

      const pricelists = await Pricelist.find();
      return pricelists;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  filterPricelist : async(args) => {
    try{
      const pricelists = await Pricelist.find({"name": {"$regex":args.name, "$options": "i"}}) ;
      return pricelists;
      }
      catch (err) {
        console.log(err);
        throw err;
      }
  }
};
