const Flatefaredetail = require('../../models/Flatefaredetails');
const Faltefare = require('../../models/Flatefares');
module.exports = {

  createFlatefaredetail: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    const flatefaredetail = new Flatefaredetail({
      pickup:args.FlatefaredetailInput.pickup,
      drop:args.FlatefaredetailInput.drop,
      spprice: args.FlatefaredetailInput.spprice,
      cusprice:args.FlatefaredetailInput.cusprice,
      rate:args.FlatefaredetailInput.rate,
      faltefare:args.FlatefaredetailInput.faltefare
    });

    let createdFlatefaredetail;
    try {
      const result = await flatefaredetail.save();
      createdFlatefaredetail = result;
      const details = await Faltefare.findById({_id:args.FlatefaredetailInput.faltefare});
      if (!details) {
        throw new Error('User not found.');
      }
      details.details.push(flatefaredetail);
      await details.save();
      //details.details
      return createdFlatefaredetail;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  destroyFlatefaredetail : async(args,req) => {
    console.log(args.flatefare);
    
    const details = await Faltefare.findById({_id:args.flatefare});
      if (!details) {
        throw new Error('Details not found.');
      }
      console.log(details.details.length);

      for(var i=0 ;i < details.details.length;i++){
          if(details.details[i]._id == args.recordID){
              
            details.details.splice(i,1);
          }
      }

      await details.save();
      return details;

  },
  Flatefaredetail : async(args,req) => {
    let currentDetails = [];
    const details = await Faltefare.findById({_id:args.flatefareId});
    if (!details) {
      throw new Error('Details not found.');
    }

    for(var i=0 ;i < details.details.length;i++){
        console.log(details.details[i]._id,args.recordId);
        if(details.details[i]._id == args.recordId){
          console.log("match");
          console.log(details.details[i])

          currentDetails = details.details[i];
        }
    }
    console.log(currentDetails,"data");
    return currentDetails;
  },
  updateFlatefaredetail : async(args) => {

    const details = await Faltefare.findById({_id:args.FlatefaredetailInput.faltefare});
    console.log(details);
    if (!details) {
      throw new Error('Details not found.');
    }

    for(var i=0 ;i < details.details.length;i++){
        console.log(details.details[i]._id,args.FlatefaredetailInput._id);

        if(details.details[i]._id == args.FlatefaredetailInput._id){ 
            console.log(args.FlatefaredetailInput)
            details.details.splice(i,1);
            details.details.splice(i, 0, args.FlatefaredetailInput);
            // details.details.push(args.FlatefaredetailInput);
            await details.save();
        } 
    }
    var Flatefares = Faltefare.find();
    return Flatefares;

  }
};
