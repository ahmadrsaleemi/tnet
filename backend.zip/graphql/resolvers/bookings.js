const Booking = require('../../models/bookings');

module.exports = {
  
  Bookings: async () => {
    try {
      const today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
      const month = today.getMonth()+1;
      const day = today.getDate() < 10 ? '0'+today.getDate():today.getDate();
      const year = today.getFullYear();

      let hours = today.getHours();
      let minutes = today.getMinutes();
      let newtime = hours + ":" + minutes;
      let newDate ="";
      if(month < 10)
      newDate = year+"-"+"0"+month+"-"+day
      else
      newDate = year+"-"+month+"-"+day

      console.log(newDate+" "+newtime.toString())
      var newDateTime = newDate+" "+newtime.toString();
      
      var filter = {};
      filter.depart = { $gte : newDateTime};

      const bookings = await Booking.find(filter).sort( { date: 1,time:1 } );
      return bookings;
    } catch (err) {
      throw err;
    }
  },
  destroyBooking: async (args) => {
    try {
      let  bookings =[];
      bookings = await Booking.findById({_id:args.recordID}) ;
      
      await Booking.deleteOne({_id:args.recordID});
      
      console.log(bookings);
     
      return bookings;
    
    } catch (err) {
      throw err;
    }
  },
  Booking : async (args, req) => {
    try{
    const bookings = await Booking.findById({_id:args.bookingId}) ;
    return bookings;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createBooking: async (args, req) => {
    if (!req.isAuth) {
      throw new Error('Unauthenticated!');
    }
    var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    var dd = String(today.getDate()).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    today = yyyy + '-' + mm + '-' + dd;

    console.log(depart);

    const booking = new Booking({
      from: args.BookingInput.from,
      to: args.BookingInput.to,
      depart: args.BookingInput.depart,
      name: args.BookingInput.name,
      cellphone:args.BookingInput.cellphone,
      segment:args.BookingInput.segment,
      created_at:today,
      creator: '5e2c16b13e911532b4c22f75'
    });
    let createdBooking;
    try {
      const result = await booking.save();
      createdBooking = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdBooking;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateBooking : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }

    try {
      const result = await Booking.update({'_id': args.attributeInput.id},
        {$set:{
        'from': args.attributeInput.name,
        "to":args.attributeInput.to,
        'depart': args.attributeInput.depart,
        "name":args.attributeInput.name,
        "cellphone":args.attributeInput.cellphone
      }
      },{multi:true});

      const bookings = await Booking.find();
      return bookings;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  totalBooking: async (args,req) => {
    try
    {
      var filter = {};

      var regex = new RegExp(["^", args.SearchBookingInput.name , "$"].join(""), "i");
      
      var regex2 = new RegExp(["^", args.SearchBookingInput._id , "$"].join(""), "i");
      
      if (regex2 != '/^$/i')
          filter.mybookingid = regex2;

      if (regex != '/^$/i')
          filter.name = regex;

      if (args.SearchBookingInput.cellphone != '' && args.SearchBookingInput.cellphone.length > 5)
          filter.cellphone =args.SearchBookingInput.cellphone;

      if (args.SearchBookingInput.status != '')
          filter.status =args.SearchBookingInput.status;
      if(args.SearchBookingInput.sprovider && args.SearchBookingInput.sprovider != '')
          filter.serviceprovide =args.SearchBookingInput.sprovider;

      if( args.SearchBookingInput.fromdate != '' && args.SearchBookingInput.todate != '')
        filter.date = { $gte : args.SearchBookingInput.fromdate , $lte : args.SearchBookingInput.todate };
      else{
          if(args.SearchBookingInput.fromdate != '')
            filter.date = { $gte : args.SearchBookingInput.fromdate };

          if(args.SearchBookingInput.todate != '')
            filter.date = { $lte : args.SearchBookingInput.todate };
      }

      // console.log(filter)

      if( Object.keys(filter).length === 0 )
      {
          const today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
          const month = today.getMonth()+1;
          const day = today.getDate() < 10 ? '0'+today.getDate():today.getDate();
          const year = today.getFullYear();
    
          let hours = today.getHours();
            hours = hours < 10 ? "0"+hours : hours;
          let minutes = today.getMinutes();
            minutes = minutes < 10 ? "0"+minutes : minutes;

          let newtime = hours + ":" + minutes;
          let newDate ="";
          if(month < 10)
          newDate = year+"-"+"0"+month+"-"+day
          else
          newDate = year+"-"+month+"-"+day
    
          console.log(newDate+" "+newtime.toString())
          var newDateTime = newDate+" "+newtime.toString();
          filter.depart = { $gte : newDateTime};
      } 
      var totalbookings =  await Booking.find(filter);
      
      // var totalbookings = await Booking.aggregate([ {
      //      $group: {
      //        _id: null,
      //        "Totalcp": {
      //            $sum: "$cp"
      //        },
      //        "Totalsp": {
      //         $sum: "$sp"
      //     }
      //      }
      //  } ] );
      
      var sp = 0;
      var cp = 0;
      var profit = 0 ;
      var canceledbookings = 0;
      // console.log(totalbookings);
      for(var i = 0; i < totalbookings.length;i++){
          console.log(totalbookings[i].status)
          if(totalbookings[i].status === "canceled"){
            canceledbookings++;
          }
          cp += parseInt(totalbookings[i].cp);
          sp += parseInt(totalbookings[i].newsp);
          profit += parseInt(totalbookings[i].cp) - parseInt(totalbookings[i].newsp);

      }

      // console.log(sp,cp,profit);

      return {totalbooking:totalbookings.length,sp,cp,profit,canceledbookings};


    } catch(err){
      console.log(err);
      throw err;
    }
  },
  
  SearchBooking : async (args,req) => {
    try
    {
      console.log(args)
      let page = parseInt(args.SearchBookingInput.page);
      let limit = 10*page;
      let from = limit-10;
      var filter = {};

      var regex = new RegExp(["^", args.SearchBookingInput.name , "$"].join(""), "i");
      var regex2 = new RegExp(["^", args.SearchBookingInput._id , "$"].join(""), "i");
      
      if (regex2 != '/^$/i')
          filter.mybookingid = regex2;

      if (regex != '/^$/i')
          filter.name = regex;

      if (args.SearchBookingInput.cellphone != '' && args.SearchBookingInput.cellphone.length > 5)
          filter.cellphone =args.SearchBookingInput.cellphone;

      if (args.SearchBookingInput.status != '')
          filter.status =args.SearchBookingInput.status;
      if(args.SearchBookingInput.sprovider && args.SearchBookingInput.sprovider != '')
          filter.serviceprovide =args.SearchBookingInput.sprovider;

      if( args.SearchBookingInput.fromdate != '' && args.SearchBookingInput.todate != '')
        filter.date = { $gte : args.SearchBookingInput.fromdate , $lte : args.SearchBookingInput.todate };
      else{
          if(args.SearchBookingInput.fromdate != '')
            filter.date = { $gte : args.SearchBookingInput.fromdate };

          if(args.SearchBookingInput.todate != '')
            filter.date = { $lte : args.SearchBookingInput.todate };
      }
      
      
      if( Object.keys(filter).length === 0 )
      {
          const today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
          let month = today.getMonth()+1;
          const day = today.getDate() < 10 ? '0'+today.getDate():today.getDate();
          const year = today.getFullYear();
    
          let hours = today.getHours();
          hours = hours < 10 ? "0"+hours : hours;
          let minutes = today.getMinutes();
          minutes = minutes < 10 ? "0"+minutes : minutes;

          let newtime = hours + ":" + minutes;
          let newDate ="";
          if(month < 10)
            newDate = year+"-"+"0"+month+"-"+day
          else
            newDate = year+"-"+month+"-"+day
    
          console.log(newDate+" "+newtime.toString())
          var newDateTime = newDate+" "+newtime.toString();
          filter.depart = { $gte : newDateTime};
          const bookings = await Booking.find(filter).limit(10).skip(from).sort( { date: 1,time:1 } );
          bookings.forEach(element => {
            console.log(element.mybookingid,element.date,element.time)
          });
          return bookings;
      }
      else{
        
        let searchresult = await Booking.find(filter).limit(10).skip(from).sort( { date: 1,time:1 } );
        searchresult.forEach(element => {
          console.log(element.mybookingid,element.date,element.time)
        });
        return searchresult;
      }
      
      
      
     
    } catch(err){
      console.log(err);
      throw err;
    }
  },
  SearchPandingBooking: async (args,req) => {
    try
    {
      // console.log(args)
      let page = parseInt(args.SearchBookingInput.page);
      let limit = 10*page;
      let from = limit-10;
      var filter = {};

      var regex = new RegExp(["^", args.SearchBookingInput.name , "$"].join(""), "i");
      var regex2 = new RegExp(["^", args.SearchBookingInput._id , "$"].join(""), "i");
      filter.status = "pending";

      if (regex2 != '/^$/i')
          filter.mybookingid = regex2;

      if (regex != '/^$/i')
          filter.name = regex;

      if (args.SearchBookingInput.cellphone != '' && args.SearchBookingInput.cellphone.length > 5)
          filter.cellphone =args.SearchBookingInput.cellphone;

      if (args.SearchBookingInput.status != '')
          filter.status =args.SearchBookingInput.status;

      if( args.SearchBookingInput.fromdate != '' && args.SearchBookingInput.todate != '')
        filter.date = { $gte : args.SearchBookingInput.fromdate , $lte : args.SearchBookingInput.todate };
      else{
          if(args.SearchBookingInput.fromdate != '')
            filter.date = { $gte : args.SearchBookingInput.fromdate };

          if(args.SearchBookingInput.todate != '')
            filter.date = { $lte : args.SearchBookingInput.todate };
      }
      
      
      let searchresult = await Booking.find(filter).limit(10).skip(from).sort( { date: 1,time:1 } );
        searchresult.forEach(element => {
          console.log(element.mybookingid,element.date,element.time)
        });
        console.log(searchresult)
        return searchresult;
      
      
      
     
    } catch(err){
      console.log(err);
      throw err;
    }
  },
  sendToken : async (args,req) => {
    return req.isAuth;
  },
  filterByNameAndId : async(args) => {
    var regex = new RegExp(["^", args.name , "$"].join(""), "i");
      
    var regex2 = new RegExp(["^", args.bookingId , "$"].join(""), "i");
    var filter = {}
    if (regex2 != '/^$/i')
        filter.mybookingid = regex2;

    if (regex != '/^$/i')
        filter.name = regex;

    const bookings = await Booking.findOne(filter);
    // console.log(bookings)
    return bookings;
  }



};