const Spmanagement = require('../../models/spmanagment');
const User = require('../../models/user');
const Geofencing = require('../../models/Geofencings');
const PriceList = require('../../models/pricelist');
const FlateFare = require('../../models/Flatefares');
const MeteredFare = require('../../models/Meteredfare');
const Segment = require('../../models/segments');
const Attribute = require('../../models/Attributes');
const AttributeGroup = require('../../models/Attributegroup');
const axios = require('axios');

module.exports = {
  Spmanagements: async () => {
    try {
      const spmanagements = await Spmanagement.find();
      //console.log(spmanagements);
      return spmanagements;
    } catch (err) {
      throw err;
    }
  },
  destroySpmanagement: async (args) => {
    //return args;
    console.log(args);
    try {
      let  spmanagements =[];
      spmanagements = await Spmanagement.findById({_id:args.recordID}) ;
      
      await Spmanagement.deleteOne({_id:args.recordID});
      
      console.log(spmanagements);
     
      return spmanagements;
    
    } catch (err) {
      throw err;
    }
  },
  Spmanagement : async (args, req) => {
    try{
    const spmanagements = await Spmanagement.findById({_id:args.spmanagementId}) ;
    // console.log(spmanagements)
    console.log(spmanagements.pricelist)
      // console.log(spmanagements.coveredarea) 
      // console.log(spmanagements.attributes)
      // console.log(spmanagements.segments)

       const pricelist = await PriceList.findById({"_id":spmanagements.pricelist})
       let geofencing = [];
       for(var area = 0 ; area < spmanagements.coveredarea.length;area++){
         const geofencings = await Geofencing.find({"_id":spmanagements.coveredarea[area]});
          for(var i = 0 ; i < geofencings.length;i++){
            geofencing.push(geofencings[i].title+"-"+geofencings[i]._id+"-"+geofencings[i].country+"-"+geofencings[i].city+"-"+geofencings[i].area);
          }
       }
      let segments = [];
      for(var segment = 0 ; segment < spmanagements.segments.length;segment++){
        const Segments = await Segment.find({"_id":spmanagements.segments[segment]});
        for(var i = 0 ; i < Segments.length;i++){
          segments.push(Segments[i].name+"-"+Segments[i]._id);
        }
      }

      let attributes = [];
      for(var attribute = 0 ; attribute < spmanagements.attributes.length;attribute++){
        const Attributes = await Attribute.find({"_id":spmanagements.attributes[attribute]});

        for(var i = 0 ; i < Attributes.length;i++){
            attributes.push(Attributes[i].name+"-"+Attributes[i]._id);
        }
      }

      
     return {
      "_id": spmanagements._id,
      "name": spmanagements.name,
      "dispatchMethod": spmanagements.dispatchMethod,
      "active": spmanagements.active,
      "allocationtime": spmanagements.allocationtime,
      "cancelationtime": spmanagements.cancelationtime,
      "pricemethod": spmanagements.pricemethod,
      "pricelist": pricelist.name+"-"+pricelist._id,
      "coveredarea":geofencing,
      "attributes": attributes,
      "segments":segments,
      "coid":spmanagements.coid,
      "customer":spmanagements.customer
    };
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createSpmanagement: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    console.log(args);
    const spmanagement = new Spmanagement({
      name: args.SpmanagementInput.name,
      dispatchMethod: args.SpmanagementInput.dispatchMethod,
      active: args.SpmanagementInput.active,
      allocationtime:args.SpmanagementInput.allocationtime,
      cancelationtime: args.SpmanagementInput.cancelationtime,
      pricelist: args.SpmanagementInput.pricelist,
      pricemethod:args.SpmanagementInput.pricemethod,
      coveredarea:args.SpmanagementInput.coveredarea,
      segments:args.SpmanagementInput.segments,
      attributes:args.SpmanagementInput.attributes,
      coid:args.SpmanagementInput.coid,
      customer:args.SpmanagementInput.customer,
      creator: '5e2c16b13e911532b4c22f75'
    });
    let createdSpmanagement;
    try {
      const result = await spmanagement.save();
      createdSpmanagement = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdSpmanagement;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateSpmanagement : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }

    try {
      console.log(args);
      const result = await Spmanagement.updateOne({'_id': args.SpmanagementInput._id},
        {$set:{
          "name": args.SpmanagementInput.name,
          "dispatchMethod": args.SpmanagementInput.dispatchMethod,
          "active": args.SpmanagementInput.active,
          "allocationtime":args.SpmanagementInput.allocationtime,
          "cancelationtime": args.SpmanagementInput.cancelationtime,
          "pricelist": args.SpmanagementInput.pricelist,
          "pricemethod":args.SpmanagementInput.pricemethod,
          "coveredarea":args.SpmanagementInput.coveredarea,
          "segments":args.SpmanagementInput.segments,
          "attributes":args.SpmanagementInput.attributes,
          "coid":args.SpmanagementInput.coid,
          "customer":args.SpmanagementInput.customer
        }
      },{multi:true});

      const spmanagements = await Spmanagement.find();
      return spmanagements;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  getSegmentsBasedOnArea : async(args) => {

   var time = 0;
   var distance = 0 ;
   let messages = [];
   const encoded = encodeURI('https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins='+args.bookingSegmentInput.from+'&destinations='+args.bookingSegmentInput.to+'&key=AIzaSyDNe857te_3slJU7_BSHGaAn47_opGBaDY');
   let timeAndDistance = await axios.get(encoded);
   for(var td=0;td < timeAndDistance.data.rows.length;td++){
        const subLoop = timeAndDistance.data.rows[td].elements;
        for(var sb=0;sb < subLoop.length;sb++){
          if(subLoop[sb].distance.value){
            distance = (parseInt(subLoop[sb].distance.value)/1000).toFixed(1);
            time = (parseInt(subLoop[sb].duration.value)/60).toFixed(1);
          }
            
        }
   } 

    var daysOfWeak = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
    var today = new Date(args.bookingSegmentInput.date).getDay();
    var hour = new Date(args.bookingSegmentInput.date).getHours();
    

    console.log("title = " , args.bookingSegmentInput.title);
    console.log("title = " , args.bookingSegmentInput.title2);
    console.log("api time",time);
    console.log("api distance",distance)
    console.log("current hour",hour);
    // return;
    console.log(args.bookingSegmentInput.title);
    const area = await Geofencing.findOne({title:args.bookingSegmentInput.title,active:true});
    // console.log(area);
    const spmanagements = await Spmanagement.find({active:"YES"});
    let bookings = [];
    let pricelist = [];
    let sp = [];
    if(spmanagements.length > 0){
    for(let i = 0; i < spmanagements.length ; i++){
      if(spmanagements[i].coveredarea.indexOf(area._id) !== -1){
          console.log(spmanagements[i]._id,"id")
          if(pricelist.indexOf(spmanagements[i].pricelist) === - 1)
            pricelist.push({id:spmanagements[i].pricelist,sp:spmanagements[i]._id});
      }
    }
    for(let pl=0;pl < pricelist.length;pl++){
        let pricelists = await PriceList.find({_id:pricelist[pl].id,active:"YES"})
        for(let j=0;j < pricelists.length; j++){
          
            for(var f=0;f < pricelists[j].flatefare.length;f++ ){
                const flatefare =await FlateFare.findById({_id:pricelists[j].flatefare[f]});
                

                if(flatefare != null){
                  for(let d=0;d < flatefare.details.length;d++){
                    if(flatefare.details[d].active === "YES")
                    {
                      
                      console.log(flatefare.details[d].starthoure,"start hour")
                      console.log(flatefare.details[d].endhoure,"end hour");
                      var starthour = flatefare.details[d].starthoure;
                      var endhour = flatefare.details[d].endhoure;
                      var startDay = daysOfWeak.indexOf(flatefare.details[d].startday);
                      var endDay = daysOfWeak.indexOf(flatefare.details[d].endday);
                      console.log(startDay,endDay,"indexes");
                      console.log(startDay,endDay,"indexes");

                      var indexArray = [];
                      if(startDay > endDay){
                        console.log("working here")
                        for(var ind=0;ind <= endDay;ind++){
                          indexArray.push(ind);
                        }

                        for(var ind=startDay;ind < 7;ind++){
                          indexArray.push(ind);
                        }
                        
                      }
                      else if(endDay > startDay){
                        console.log("working here 2")
                        for(var ind=startDay; ind <= endDay;ind++){
                          indexArray.push(ind);
                        }

                      }
                    console.log(indexArray);

                    console.log(indexArray.indexOf(today),today,"today existance index")
                    console.log(flatefare.details[d].pickup.toLowerCase() , args.bookingSegmentInput.title.toLowerCase() 
                    , flatefare.details[d].drop.toLowerCase() , args.bookingSegmentInput.title2.toLowerCase())

                    let fromTo = false;
                    if(flatefare.details[d].rate === "Both-way"){
                      if(flatefare.details[d].pickup.toLowerCase().trim() === args.bookingSegmentInput.title2.toLowerCase().trim() 
                          && flatefare.details[d].drop.toLowerCase().trim() === args.bookingSegmentInput.title.toLowerCase().trim())
                      fromTo = true
                      if(flatefare.details[d].pickup.toLowerCase().trim() === args.bookingSegmentInput.title.toLowerCase().trim() 
                          && flatefare.details[d].drop.toLowerCase().trim() === args.bookingSegmentInput.title2.toLowerCase().trim())
                      fromTo = true
                    }
                    else{
                      if(flatefare.details[d].pickup.toLowerCase().trim() === args.bookingSegmentInput.title.toLowerCase().trim() 
                          && flatefare.details[d].drop.toLowerCase().trim() === args.bookingSegmentInput.title2.toLowerCase().trim())
                      fromTo = true
                    }
                        if(fromTo)
                          {

                            if(indexArray.indexOf(today) > -1){

                              if(hour >= starthour && hour < endhour){
                                console.log("true")
                              for(let cus=0;cus < flatefare.details[d].cusprice.length;cus++ ){
                                console.log({segment:flatefare.details[d].cusprice[cus].split('-------')[0],price:flatefare.details[d].cusprice[cus].split('-------')[1]});
                                bookings.push({sp:pricelist[pl].sp,segment:flatefare.details[d].cusprice[cus].split('-------')[0],price:flatefare.details[d].cusprice[cus].split('-------')[1]})
                                sp.push({sp:pricelist[pl],segment:flatefare.details[d].spprice[cus].split('-------')[0],price:flatefare.details[d].spprice[cus].split('-------')[1]});
                              }

                             
                            }else{ messages.push("SP not available on the following time or day Flatfare") }
                          }else{messages.push("flatfare day does not match match") }
                        
                      }
                      else{
                        messages.push("flatfare pickup and drop do not match")
                      }
                    }
                  }
                }

            }

            let meteredFareDetails = [] ;
            let meteredfaresp = [];
            for(var m=0;m < pricelists[j].meteredfare.length;m++ ){
                const meteredfare =await MeteredFare.findById({_id:pricelists[j].meteredfare[m]});
                var starthour2 = meteredfare.starthoure;
                var endhour2 = meteredfare.endhoure;
                var startDay2 = daysOfWeak.indexOf(meteredfare.startday);
                var endDay2 = daysOfWeak.indexOf(meteredfare.endday);

                var indexArray2 = [];
                      if(startDay2 > endDay2){
                        console.log("working here")
                        for(var ind=0;ind <= endDay2;ind++){
                          indexArray2.push(ind);
                        }

                        for(var ind=startDay2;ind < 7;ind++){
                          indexArray2.push(ind);
                        }
                        
                      }
                      else if(endDay2 > startDay2){
                        console.log("working here 2")
                        for(var ind=startDay2; ind <= endDay2;ind++){
                          indexArray2.push(ind);
                        }

                      }
                      
                    console.log(indexArray2);

                    console.log(indexArray2.indexOf(today),today,"today existance index")
                if(meteredfare.active === "YES"){
                  if(indexArray2.indexOf(today) > -1){
                    if(hour >= starthour2 && hour < endhour2){
                      
                      if(meteredfare.distancebased.length > 0){
                        console.log(meteredfare.distancebased.length,"distancebase");
                        for(let d=0;d < meteredfare.distancebased.length;d++){
                          const minDistance = meteredfare.distancebased[d].distance.split('-')[0];
                          const maxDistance = meteredfare.distancebased[d].distance.split('-')[1];
                          console.log(minDistance,maxDistance)
                          console.log("distancebased minDistance :" ,minDistance,"distancebased maxDistance :",maxDistance);
                          if(parseInt(distance) >= parseInt(minDistance) && parseInt(distance) <= parseInt(maxDistance)){
                            console.log("distancebased minDistance Now:" ,minDistance,"distancebased maxDistance Now:",maxDistance);
                            for(let cus=0;cus < meteredfare.distancebased[d].cusprice.length;cus++ ){
                              console.log("Start Up Fee",meteredfare.distancebased[d].startup);
                              console.log("distancebased",{segment:meteredfare.distancebased[d].cusprice[cus].split('-------')[0],price:meteredfare.distancebased[d].cusprice[cus].split('-------')[1]});
                              console.log("distancebased after start up fee",parseFloat(meteredfare.distancebased[d].cusprice[cus].split('-------')[1])+parseFloat(meteredfare.distancebased[d].startup))
                              
                              meteredFareDetails.push({sp:pricelist[pl].sp,segment:meteredfare.distancebased[d].cusprice[cus].split('-------')[0],price:((parseFloat(meteredfare.distancebased[d].cusprice[cus].split('-------')[1])*parseFloat(distance))+parseFloat(meteredfare.distancebased[d].startup) ) })
                              meteredfaresp.push({sp:pricelist[pl].sp,segment:meteredfare.distancebased[d].spprice[cus].split('-------')[0],price:((parseFloat(meteredfare.distancebased[d].spprice[cus].split('-------')[1])*parseFloat(distance))+parseFloat(meteredfare.distancebased[d].startup) ) });
                            
                            }
                          } else{
                            messages.push("Distance not in range")
                          }
                        }
                      }
                      if(meteredfare.timebased.length > 0){
                        for(let d=0;d < meteredfare.timebased.length;d++){
                          const minTime = meteredfare.timebased[d].distance.split('-')[0];
                          const maxTime = meteredfare.timebased[d].distance.split('-')[1];
                          console.log("timebased mintime :" ,minTime,"timebased maxtim :",maxTime);

                          if(parseInt(time) >= parseInt(minTime) && parseInt(distance) <= parseInt(maxTime)){
                            console.log("timebased mintime NOW:" ,minTime,"timebased maxtim NOW:",maxTime);
                            
                            for(let cus=0;cus < meteredfare.timebased[d].cusprice.length;cus++ ){
                              console.log("Start Up Fee",meteredfare.timebased[d].startup);
                              console.log("timebased :" , {segment:meteredfare.timebased[d].cusprice[cus].split('-------')[0],price:meteredfare.timebased[d].cusprice[cus].split('-------')[1]})
                              console.log("after start up fee",parseFloat(meteredfare.timebased[d].cusprice[cus].split('-------')[1]) + parseFloat(meteredfare.timebased[d].startup));
                              meteredFareDetails.push({sp:pricelist[pl].sp,segment:meteredfare.timebased[d].cusprice[cus].split('-------')[0],price:((parseFloat(meteredfare.timebased[d].cusprice[cus].split('-------')[1]*parseFloat(time)))+parseFloat(meteredfare.timebased[d].startup))})
                              meteredfaresp.push({sp:pricelist[pl].sp,segment:meteredfare.timebased[d].spprice[cus].split('-------')[0],price:((parseFloat(meteredfare.timebased[d].spprice[cus].split('-------')[1]*parseFloat(time)))+parseFloat(meteredfare.timebased[d].startup) ) });
                            }
                          }else{
                            messages.push("Time not in range")
                          }
                        } 
                      }  
                  } else{
                    messages.push("SP not available on the following time or day MeteredFare")
                  }
                }
                else{
                  messages.push("Meteredfare day does not match match")
                }
                }

            }
            result = [];

            meteredFareDetails.forEach(function (a) {
                  if (!this[a.segment]) {
                      this[a.segment] = { sp:a.sp,segment: a.segment, price: 0 };
                      result.push(this[a.segment]);
                  }
                  this[a.segment].price += parseInt(a.price);
              }, Object.create(null));

            let result2 = [] ;
            meteredfaresp.forEach(function (a) {
                if (!this[a.segment]) {
                    this[a.segment] = { sp:a.sp,segment: a.segment, price: 0 };
                    result2.push(this[a.segment]);
                }
                this[a.segment].price += parseInt(a.price);
            }, Object.create(null));

              // console.log(result);
              for(let r=0;r < result.length;r++){
                bookings.push(result[r]);
              }

              for(let r=0;r < result2.length;r++){
                sp.push(result2[r]);
              }
              
          }    
    }
    console.log("bookings",bookings)
    const array=bookings;
    const array2 = sp;
    const arrayFiltered = [];
    const arrayFiltered2 = [];

    array.forEach(obj => {
        const item = arrayFiltered.find(thisItem => thisItem.segment === obj.segment);
        if (item) {
            if (item.price > obj.price) {
                item.price = obj.price;
            }
            
            return;
        }
        
        arrayFiltered.push(obj);
    });
    
    var spArray = [];
    array.forEach(obj => {
      const item = spArray.find(thisItem => thisItem.sp === obj.sp);
          if (item) {
              if (item.sp > obj.sp) 
              return;
          }
          
          spArray.push(obj.sp);
    });
    console.log("i am here")
    array2.forEach(obj => {
      const item = arrayFiltered2.find(thisItem => thisItem.segment === obj.segment);
      if (item) {
          if (item.price > obj.price) {
              item.price = obj.price;
          }
          
          return;
      }
      
      arrayFiltered2.push(obj);
    });

  console.log(arrayFiltered2,"sps");

    var dataToSend = [] ;
    
    for(var i=0;i < arrayFiltered.length;i++){
      const segment = await Segment.findOne({'name':arrayFiltered[i].segment});
      console.log(segment);
      dataToSend.push({
      'segment':arrayFiltered[i].segment,
      'price':arrayFiltered[i].price,
      'image':segment.image,
       'pcap':segment.passanger_capacity,
       'order':segment.Order,
       })
    }

    var dataToSend2 = [] ;
    for(var i=0;i < arrayFiltered2.length;i++){
      const segment = await Segment.findOne({'name':arrayFiltered2[i].segment});
      console.log(segment);
      dataToSend2.push({
      'segment':arrayFiltered2[i].segment,
      'price':arrayFiltered2[i].price,
      'image':segment.image,
       'pcap':segment.passanger_capacity,
       'order':segment.Order,
       })

    }
    let dataToSend3 =[];
    
    for(var m =0;m < messages.length;m++){
      console.log()
      dataToSend3.push({
      'segment':messages[m],
      'price':messages[m],
      'image':messages[m],
       'pcap':messages[m],
       'order':messages[m],
       sp:messages[m],
       })
    }
    function onlyUnique(value, index, self) { 
        return self.indexOf(value) === index;
    }

    var uniqueSp = spArray.filter( onlyUnique );
    console.log(uniqueSp[0] );
    const spToSend = await Spmanagement.findById({_id:uniqueSp[0] })
    console.log("data to send",spToSend)


    var dataToSend4 =[{segment: spToSend._id, price: spToSend.name, image: spToSend.coid, pcap: spToSend.customer,order:"test"}];
    var finalData = [dataToSend,dataToSend2,dataToSend3,dataToSend4]
    console.log(finalData);

    return finalData;
  }
    
  },
  attributespcp : async() => {

    const attributeGroups = await AttributeGroup.find({active:"YES"});
    var sp = [];
    var spname=[];
    var cp = [];
    var cpname=[];
    for(var i = 0;i < attributeGroups.length;i++){
        console.log(attributeGroups[i].spprice,attributeGroups[i].cusprice);
        for(var spi=0;spi < attributeGroups[i].spprice.length;spi++){
          const name = attributeGroups[i].spprice[spi].split("-------")[0];
          const price = attributeGroups[i].spprice[spi].split("-------")[1];
          sp.push({ name :name , price: price })
        }


        for(var cpi=0;cpi < attributeGroups[i].cusprice.length;cpi++){
          const name = attributeGroups[i].cusprice[cpi].split("-------")[0];
          const price = attributeGroups[i].cusprice[cpi].split("-------")[1];
          cp.push({ name :name,price: price })
        }
    }
    const arrayFiltered = [];
    sp.forEach(obj => {
      const item = arrayFiltered.find(thisItem => thisItem.name === obj.name);
          if (item) {
              if (item.price > obj.price) {
                  item.price = obj.price;
              }
              
              return;
          }
          
          arrayFiltered.push(obj);
      });

    const arrayFiltered2 = [];
    cp.forEach(obj => {
      const item = arrayFiltered2.find(thisItem => thisItem.name === obj.name);
          if (item) {
              if (item.price > obj.price) {
                  item.price = obj.price;
              }
              
              return;
          }
          
          arrayFiltered2.push(obj);
      });

      cp = [];
      for(var i = 0; i < arrayFiltered2.length;i++){
        cp.push(arrayFiltered2[i].name+"-"+arrayFiltered2[i].price)
      }

      sp = [];
      for(var i = 0; i < arrayFiltered.length;i++){
        sp.push(arrayFiltered[i].name+"-"+arrayFiltered[i].price)
      }

      console.log(cp,sp);
      return {cp:cp,sp:sp}
  },
  filterSpmanagement : async(args) => {
    console.log(args)
    try
    {

      let searchresult =[];
      var filter = {};

      var regex = new RegExp(["^", args.segment , "$"].join(""), "i");
      
      if (args.area != '')
          filter.area = args.area;

      if (args.segment)
          filter.title = args.segment;
      if (args.city)
          filter.city = args.city;


      console.log(filter);
       var geofencing = await Geofencing.find();
       console.log(geofencing);

    } catch(err){
      console.log(err);
      throw err;
    }
  }
};
