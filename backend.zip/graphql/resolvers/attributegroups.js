const AttributeGroup = require('../../models/Attributegroup');


module.exports = {
 Attributegroups: async (args) => {
   
    try {
      const attributegroups = await AttributeGroup.find();
      return attributegroups;
    } catch (err) {
      throw err;
    }
  },
  destroyAttributeGroup: async (args, req) => {
    if (!req.isAuth) {
      throw new Error('Unauthenticated!');
    }
    console.log(args);
    try {
      let  attributegroups =[];
      attributegroups = await AttributeGroup.findById({_id:args.recordID}) ;
      
      await AttributeGroup.deleteOne({_id:args.recordID});
      
      console.log(attributegroups);
     
      return attributegroups;
    
    } catch (err) {
      throw err;
    }
  },
  Attributegroup : async (args, req) => {
    try{
    const attributegroups = await AttributeGroup.findById({_id:args.AttributegroupId}) ;
    return attributegroups;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createAttributeGroup: async (args, req) => {
    if (!req.isAuth) {
      throw new Error('Unauthenticated!');
    }
    const attributegroup = new AttributeGroup({
      name: args.AttributeGroupInput.name,
      spprice: args.AttributeGroupInput.spprice,
      cusprice: args.AttributeGroupInput.cusprice,
      active: args.AttributeGroupInput.active,
      creator: '5e2c16b13e911532b4c22f75'
    });
    let createdAttributeGroup;
    try {
      const result = await attributegroup.save();
      createdAttributeGroup = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdAttributeGroup;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateAttributeGroup : async (args, req) => {
    if (!req.isAuth) {
      throw new Error('Unauthenticated!');
    }
    try {
      const result = await AttributeGroup.update({'_id': args.AttributeGroupInput._id},
        {$set:{
        'name': args.AttributeGroupInput.name,
        "spprice":args.AttributeGroupInput.spprice,
        "cusprice":args.AttributeGroupInput.cusprice,
        "active":args.AttributeGroupInput.active
        }
      },{multi:true});
      if(result){
        const attributegroups = await AttributeGroup.find();
        return attributegroups;
        }
      
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  filterAttributeGroup : async(args, req) => {
    try{
      const attributegroups = await AttributeGroup.find({"name": {"$regex":args.name, "$options": "i"}}) ;
      return attributegroups;
      }
      catch (err) {
        console.log(err);
        throw err;
      }
  }
};
