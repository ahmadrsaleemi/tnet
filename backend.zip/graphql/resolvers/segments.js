const Segment = require('../../models/segments');
const User = require('../../models/user');
const { transformEvent } = require('./merge');
const Flatefare = require('../../models/Flatefares');
module.exports = {
  segments: async () => {
    try {
      const segments = await Segment.find();
      return segments;
    } catch (err) {
      throw err;
    }
  },
  destroySegment: async (args,res) => {
    try {
      let flatefares =await Flatefare.find();
      
      let  segments =[];
      segments = await Segment.findById({_id:args.recordID});
      for(let f=0;f < flatefares.length;f++){
        for(let i=0;i < flatefares[f].details.length;i++){
              console.log(flatefares[f].details[i])
                let spprice = flatefares[f].details[i].spprice;
                let cusprice = flatefares[f].details[i].cusprice;
                for(let j = 0 ; j < spprice.length;j++){
                  if(segments.name === spprice[j].split('-------')[0])
                    return false;
                }
                for(let j = 0 ; j < cusprice.length;j++){
                  if(segments.name === cusprice[j].split('-------')[0])
                  return false;
                }
            }
      }
      await Segment.deleteOne({_id:args.recordID});
      return segments;
    
    } catch (err) {
      throw err;
    }
  },
  segment : async (args, req) => {
    try{
    const segments = await Segment.findById({_id:args.segmentId}) ;
    return segments;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createSegment: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    const segment = new Segment({
      name: args.segmentInput.name,
      passanger_capacity: args.segmentInput.passanger_capacity,
      Order: args.segmentInput.Order,
      bag: args.segmentInput.bag,
      date:"2020-02-03T10:41:20.673Z",
      creator: '5e2c16b13e911532b4c22f75'
    });
    let createdSegment;
    try {
      const result = await segment.save();
      createdSegment = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdSegment;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateSegment : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    let createdSegment;
    try {
      const result = await Segment.update({'_id': args.segmentInput.id},
        {$set:{
        'name': args.segmentInput.name,
        'passanger_capacity': args.segmentInput.passanger_capacity,
        "Order":args.segmentInput.Order,
        "bag": args.segmentInput.bag
      }
      },{multi:true});

      const segments = await Segment.find();
      return segments;
    } catch (err) {
      console.log(err);
      throw err;
    }
  }
};
