const Spmanagement = require('../../models/spmanagment');
const User = require('../../models/user');
const Geofencing = require('../../models/Geofencings');
const PriceList = require('../../models/pricelist');
const FlateFare = require('../../models/Flatefares');
const MeteredFare = require('../../models/Meteredfare');
const Segment = require('../../models/segments');
const Attribute = require('../../models/Attributes');
const AttributeGroup = require('../../models/Attributegroup');
const axios = require('axios');
const _ = require('underscore');
module.exports = {
    Spmanagements: async () => {
        try {
            const spmanagements = await Spmanagement.find();
            //console.log(spmanagements);
            return spmanagements;
        } catch (err) {
            throw err;
        }
    },
    destroySpmanagement: async (args) => {
        //return args;
        console.log(args);
        try {
            let spmanagements = [];
            spmanagements = await Spmanagement.findById({
                _id: args.recordID
            });

            await Spmanagement.deleteOne({
                _id: args.recordID
            });

            console.log(spmanagements);

            return spmanagements;

        } catch (err) {
            throw err;
        }
    },
    Spmanagement: async (args, req) => {
        try {
            const spmanagements = await Spmanagement.findById({
                _id: args.spmanagementId
            });
            // console.log(spmanagements)
            console.log(spmanagements.pricelist)
            // console.log(spmanagements.coveredarea) 
            // console.log(spmanagements.attributes)
            // console.log(spmanagements.segments)

            const pricelist = await PriceList.findById({
                "_id": spmanagements.pricelist
            })
            let geofencing = [];
            for (var area = 0; area < spmanagements.coveredarea.length; area++) {
                const geofencings = await Geofencing.find({
                    "_id": spmanagements.coveredarea[area]
                });
                for (var i = 0; i < geofencings.length; i++) {
                    geofencing.push(geofencings[i].title + "-" + geofencings[i]._id + "-" + geofencings[i].country + "-" + geofencings[i].city + "-" + geofencings[i].area);
                }
            }
            let segments = [];
            for (var segment = 0; segment < spmanagements.segments.length; segment++) {
                const Segments = await Segment.find({
                    "name": spmanagements.segments[segment]
                });
                for (var i = 0; i < Segments.length; i++) {
                    segments.push(Segments[i].name + "-" + Segments[i]._id);
                }
            }

            let attributes = [];
            for (var attribute = 0; attribute < spmanagements.attributes.length; attribute++) {
                const Attributes = await Attribute.find({
                    "_id": spmanagements.attributes[attribute]
                });

                for (var i = 0; i < Attributes.length; i++) {
                    attributes.push(Attributes[i].name + "*" + Attributes[i]._id);
                }
            }


            return {
                "_id": spmanagements._id,
                "name": spmanagements.name,
                "dispatchMethod": spmanagements.dispatchMethod,
                "active": spmanagements.active,
                "allocationtime": spmanagements.allocationtime,
                "cancelationtime": spmanagements.cancelationtime,
                "pricemethod": spmanagements.pricemethod,
                "pricelist": pricelist.name + "-" + pricelist._id,
                "coveredarea": geofencing,
                "attributes": attributes,
                "segments": segments,
                "coid": spmanagements.coid,
                "customer": spmanagements.customer
            };
        } catch (err) {
            console.log(err);
            throw err;
        }
    },
    createSpmanagement: async (args, req) => {
        // if (!req.isAuth) {
        //   throw new Error('Unauthenticated!');
        // }
        console.log(args);
        var attributes = args.SpmanagementInput.attributes;

        var newAttributes = [];
        for(var i = 0;i < attributes.length;i++ ){
            if(newAttributes.indexOf(attributes[i]) === -1)
                newAttributes.push(attributes[i])
        }
        const spmanagement = new Spmanagement({
            name: args.SpmanagementInput.name,
            dispatchMethod: args.SpmanagementInput.dispatchMethod,
            active: args.SpmanagementInput.active,
            allocationtime: args.SpmanagementInput.allocationtime,
            cancelationtime: args.SpmanagementInput.cancelationtime,
            pricelist: args.SpmanagementInput.pricelist,
            pricemethod: args.SpmanagementInput.pricemethod,
            coveredarea: args.SpmanagementInput.coveredarea,
            segments: args.SpmanagementInput.segments,
            attributes: newAttributes,
            coid: args.SpmanagementInput.coid,
            customer: args.SpmanagementInput.customer,
            creator: '5e2c16b13e911532b4c22f75'
        });
        let createdSpmanagement;
        try {
            const result = await spmanagement.save();
            createdSpmanagement = result;
            // const creator = await User.findById('5e2c16b13e911532b4c22f75');

            // if (!creator) {
            //   throw new Error('User not found.');
            // }
            // creator.createdEvents.push(segment);
            // await creator.save();

            return createdSpmanagement;
        } catch (err) {
            console.log(err);
            throw err;
        }
    },
    updateSpmanagement: async (args, req) => {
        // if (!req.isAuth) {
        //   throw new Error('Unauthenticated!');
        // }

        try {
            var attributes = args.SpmanagementInput.attributes;

            var newAttributes = [];
            for(var i = 0;i < attributes.length;i++ ){
                if(newAttributes.indexOf(attributes[i]) === -1)
                    newAttributes.push(attributes[i])
            }
            const result = await Spmanagement.updateOne({
                '_id': args.SpmanagementInput._id
            }, {
                $set: {
                    "name": args.SpmanagementInput.name,
                    "dispatchMethod": args.SpmanagementInput.dispatchMethod,
                    "active": args.SpmanagementInput.active,
                    "allocationtime": args.SpmanagementInput.allocationtime,
                    "cancelationtime": args.SpmanagementInput.cancelationtime,
                    "pricelist": args.SpmanagementInput.pricelist,
                    "pricemethod": args.SpmanagementInput.pricemethod,
                    "coveredarea": args.SpmanagementInput.coveredarea,
                    "segments": args.SpmanagementInput.segments,
                    "attributes": newAttributes,
                    "coid": args.SpmanagementInput.coid,
                    "customer": args.SpmanagementInput.customer
                }
            }, {
                multi: true
            });

            const spmanagements = await Spmanagement.find();
            return spmanagements;
        } catch (err) {
            console.log(err);
            throw err;
        }
    },
    getSegmentsBasedOnArea: async (args) => {

        var time = 0;
        var distance = 0;
        let messages = [];
        const encoded = encodeURI('https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=' + args.bookingSegmentInput.from + '&destinations=' + args.bookingSegmentInput.to + '&key=AIzaSyDNe857te_3slJU7_BSHGaAn47_opGBaDY');
        let timeAndDistance = await axios.get(encoded);
        for (var td = 0; td < timeAndDistance.data.rows.length; td++) {
            const subLoop = timeAndDistance.data.rows[td].elements;
            for (var sb = 0; sb < subLoop.length; sb++) {
                if (subLoop[sb].distance.value) {
                    distance = Math.round(parseInt(subLoop[sb].distance.value) / 1000).toFixed(1);
                    time = Math.round(parseInt(subLoop[sb].duration.value) / 60).toFixed(1);
                }

            }
        }

        var daysOfWeak = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        var today = new Date(args.bookingSegmentInput.date).getDay();
        var hour = new Date(args.bookingSegmentInput.date).getHours();
        const title = args.bookingSegmentInput.title;
        const title2 = args.bookingSegmentInput.title2;
        console.log(args.bookingSegmentInput.sps,"sp");
        console.log("title = ", args.bookingSegmentInput.title);
        console.log("title = ", args.bookingSegmentInput.title2);
        console.log("api time", time);
        console.log("api distance", distance)
        console.log("current hour", hour);

        const spmanagements = await Spmanagement.find({
            _id:{$in:args.bookingSegmentInput.sps},
            active: "YES"
        });
        let bookings = [];
        let pricelist = [];
        let sp = [];
        let areas = [];
        let spAreas =[];
        if (spmanagements.length > 0) {
            for (let i = 0; i < spmanagements.length; i++) {
                if (pricelist.indexOf(spmanagements[i].pricelist) === -1)
                    pricelist.push({
                        id: spmanagements[i].pricelist,
                        sp: spmanagements[i]._id,
                        spname: spmanagements[i].name
                    });
            
                const area = await Geofencing.find({_id:{$in:spmanagements[i].coveredarea}});
                    for(var a=0;a < area.length;a++){
                        spAreas.push(area[a].title);
                    }
                
            }
            console.log(pricelist,"all spareas");

            for (let pl = 0; pl < pricelist.length; pl++) {
                let pricelists = await PriceList.find({
                    _id: pricelist[pl].id,
                    active: "YES"
                })
                var spinpl = await Spmanagement.findById({"_id":pricelist[pl].sp})
                console.log(spinpl.segments,"spsegments")
                for (let j = 0; j < pricelists.length; j++) {
                    
                    for (var f = 0; f < pricelists[j].flatefare.length; f++) {
                        const flatefare = await FlateFare.findById({
                            _id: pricelists[j].flatefare[f]
                        });


                        if (flatefare != null && flatefare.active === "YES") {
                          console.log(flatefare.starthoure, "start hour")
                          console.log(flatefare.endhoure, "end hour");
                          var starthour = flatefare.starthoure;
                          var endhour = flatefare.endhoure;
                          var startDay = daysOfWeak.indexOf(flatefare.startday);
                          var endDay = daysOfWeak.indexOf(flatefare.endday);
                          console.log(startDay, endDay, "indexes");
                          console.log(startDay, endDay, "indexes");
                          var indexArray = [];
                          if (startDay > endDay) {
                              console.log("working here")
                              for (var ind = 0; ind <= endDay; ind++) {
                                  indexArray.push(ind);
                              }

                              for (var ind = startDay; ind < 7; ind++) {
                                  indexArray.push(ind);
                              }

                          } else if (endDay > startDay) {
                              console.log("working here 2")
                              for (var ind = startDay; ind <= endDay; ind++) {
                                  indexArray.push(ind);
                              }

                          }
                          console.log(indexArray,_.intersection(spAreas, title),_.intersection(spAreas, title2));
                          
                            for (let d = 0; d < flatefare.details.length; d++) {
                                    let fromTo = false;
                                if (_.intersection(spAreas, title).length > 0 && _.intersection(spAreas, title2).length > 0) {

                                    if (flatefare.details[d].rate.toLowerCase() === "both-way") {
                                        console.log("bothways")
                                        if (args.bookingSegmentInput.title2.includes(flatefare.details[d].pickup)  &&
                                        args.bookingSegmentInput.title.includes(flatefare.details[d].drop))
                                            fromTo = true
                                        if (args.bookingSegmentInput.title2.includes(flatefare.details[d].drop)  &&
                                        args.bookingSegmentInput.title.includes(flatefare.details[d].pickup))
                                            fromTo = true
                                    } else {
                                        if (args.bookingSegmentInput.title2.includes(flatefare.details[d].drop)  &&
                                        args.bookingSegmentInput.title.includes(flatefare.details[d].pickup))
                                            fromTo = true
                                            console.log("bothways")
                                    }    
                                }

                                    
                                    console.log(fromTo ,"fromto")
                                    let hoursAndDays = false;
                                    if (fromTo) {
                                        if(flatefare.allday === "NO"){
                                            if (indexArray.indexOf(today) > -1) {

                                                if (hour >= starthour && hour < endhour) {
                                                    hoursAndDays = true;

                                                } else {
                                                    messages.push("We are not offering service on requested pickup or drop address")
                                                }
                                            } else {
                                                messages.push("We are not offering service on requested pickup or drop address")
                                            }
                                        }
                                        else{
                                            // console.log("all day active",indexArray[0],
                                            // indexArray[indexArray.length-1],today,hour,)

                                            if (indexArray[0] === today) {
                                                if (hour >= starthour && hour < 24) {
                                                    hoursAndDays = true;
                                                } else {
                                                    messages.push("We are not offering service on requested pickup or drop address")
                                                }
                                            }

                                            if (indexArray[indexArray.length-1] === today) {
                                                console.log(hour,starthour,endhour)
                                                if (hour >= 0 && hour < endhour) {
                                                    console.log("second condition")
                                                    hoursAndDays = true;
                                                } else {
                                                    messages.push("We are not offering service on requested pickup or drop address")
                                                }
                                            }

                                            if (indexArray.indexOf(today) > -1 && indexArray[indexArray.length-1] !== today && indexArray[0] !== today) {
                                                if (hour >= 0 && hour < 24) {
                                                    hoursAndDays = true;
                                                } else {
                                                    messages.push("We are not offering service on requested pickup or drop address")
                                                }
                                            }

                                        }

                                        if(hoursAndDays === true){
                                            for (let cus = 0; cus < flatefare.details[d].cusprice.length; cus++) {
                                                console.log({
                                                    segment: flatefare.details[d].cusprice[cus].split('-------')[0],
                                                    price: flatefare.details[d].cusprice[cus].split('-------')[1]
                                                });
                                                console.log(pricelist[pl].sp,pricelist[pl].spname,flatefare.details[d].cusprice[cus].split('-------')[0].toString())
                                                if(spinpl.segments.includes(flatefare.details[d].cusprice[cus].split('-------')[0].toString())){
                                                    if(flatefare.details[d].cusprice[cus].split('-------')[1] !== ""){
                                                        bookings.push({
                                                            sp: pricelist[pl].sp,
                                                            spname: pricelist[pl].spname,
                                                            segment: flatefare.details[d].cusprice[cus].split('-------')[0],
                                                            price: flatefare.details[d].cusprice[cus].split('-------')[1]
                                                        })
                                                        sp.push({
                                                            sp: pricelist[pl],
                                                            segment: flatefare.details[d].spprice[cus].split('-------')[0],
                                                            price: flatefare.details[d].spprice[cus].split('-------')[1]
                                                        });
                                                    }
                                                    
                                                }
                                                
                                            }
                                        }

                                    } else {
                                        messages.push("We are not offering service on requested pickup or drop address")
                                    }
                                
                            }
                        }else {
                            messages.push("We are not offering service on requested pickup or drop address")
                        }

                    }

                    let meteredFareDetails = [];
                    let meteredfaresp = [];
                    for (var m = 0; m < pricelists[j].meteredfare.length; m++) {
                        const meteredfare = await MeteredFare.findById({
                            _id: pricelists[j].meteredfare[m]
                        });
                        console.log(meteredfare);
                        var starthour2 = meteredfare.starthoure;
                        var endhour2 = meteredfare.endhoure;
                        var startDay2 = daysOfWeak.indexOf(meteredfare.startday);
                        var endDay2 = daysOfWeak.indexOf(meteredfare.endday);

                        var indexArray2 = [];
                        if (startDay2 > endDay2) {
                            console.log("working here")
                            for (var ind = 0; ind <= endDay2; ind++) {
                                indexArray2.push(ind);
                            }

                            for (var ind = startDay2; ind < 7; ind++) {
                                indexArray2.push(ind);
                            }

                        } else if (endDay2 > startDay2) {
                            console.log("working here 2 mm")
                            for (var ind = startDay2; ind <= endDay2; ind++) {
                                indexArray2.push(ind);
                            }

                        }

                        console.log(indexArray2);

                        console.log(indexArray2.indexOf(today), today, "today existance index 2")
                        if (meteredfare.active === "YES") {
                            if (_.intersection(spAreas, title).length > 0 && _.intersection(spAreas, title2).length > 0) {
                                let hoursAndDays = false;
                                    if (meteredfare.allday === "NO") {
                                        if (indexArray2.indexOf(today) > -1) {
                    
                                            if (hour >= starthour2 && hour < endhour2) {
                                                hoursAndDays = true;
                    
                                            } else {
                                                messages.push("We are not offering service on requested pickup or drop address")
                                            }
                                        } else {
                                            messages.push("We are not offering service on requested pickup or drop address")
                                        }
                                    } 
                                    else {
                                        console.log(starthour2)
                                        if (indexArray2[0] === today) {
                                            if (hour >= starthour2 && hour < 24) {
                                                hoursAndDays = true;
                                            } else {
                                                messages.push("We are not offering service on requested pickup or drop address")
                                            }
                                        }
                    
                                        if (indexArray2[indexArray2.length - 1] === today) {
                                            
                                            if (hour >= 0 && hour < endhour2) {
                                                console.log("second condition")
                                                hoursAndDays = true;
                                            } else {
                                                messages.push("We are not offering service on requested pickup or drop address")
                                            }
                                        }
                    
                                        if (indexArray2.indexOf(today) > -1 && indexArray2[indexArray2.length - 1] !== today && indexArray2[0] !== today) {
                                            console.log("working here")
                                            if (hour >= 0 && hour < 24) {
                                                hoursAndDays = true;
                                            } else {
                                                messages.push("We are not offering service on requested pickup or drop address")
                                            }
                                        }
                                    }
                    
                                    if (hoursAndDays === true) {
                    
                                        if (meteredfare.distancebased.length > 0) {
                                            console.log(meteredfare.distancebased.length, "distancebase");
                                            for (let d = 0; d < meteredfare.distancebased.length; d++) {
                                                const minDistance = meteredfare.distancebased[d].distance.split('-')[0];
                                                const maxDistance = meteredfare.distancebased[d].distance.split('-')[1];
                                                console.log(minDistance, maxDistance)
                                                console.log("distancebased minDistance :", minDistance, "distancebased maxDistance :", maxDistance);
                                                if (parseInt(distance) >= parseInt(minDistance) && parseInt(distance) <= parseInt(maxDistance)) {
                                                    console.log("distancebased minDistance Now:", minDistance, "distancebased maxDistance Now:", maxDistance);
                                                    for (let cus = 0; cus < meteredfare.distancebased[d].cusprice.length; cus++) {
                                                        console.log("Start Up Fee", meteredfare.distancebased[d].startup);
                                                        console.log("distancebased", {
                                                            segment: meteredfare.distancebased[d].cusprice[cus].split('-------')[0],
                                                            price: meteredfare.distancebased[d].cusprice[cus].split('-------')[1]
                                                        });
                                                        console.log("distancebased after start up fee", parseFloat(meteredfare.distancebased[d].cusprice[cus].split('-------')[1]) + parseFloat(meteredfare.distancebased[d].startup))
                    
                                                        meteredFareDetails.push({
                                                            sp: pricelist[pl].sp,
                                                            spname: pricelist[pl].spname,
                                                            segment: meteredfare.distancebased[d].cusprice[cus].split('-------')[0],
                                                            price: ((parseFloat(meteredfare.distancebased[d].cusprice[cus].split('-------')[1]) * parseFloat(distance)) + parseFloat(meteredfare.distancebased[d].startup))
                                                        })
                                                        meteredfaresp.push({
                                                            sp: pricelist[pl].sp,
                                                            segment: meteredfare.distancebased[d].spprice[cus].split('-------')[0],
                                                            price: ((parseFloat(meteredfare.distancebased[d].spprice[cus].split('-------')[1]) * parseFloat(distance)) + parseFloat(meteredfare.distancebased[d].startup))
                                                        });
                    
                                                    }
                                                } else {
                                                    messages.push("We are not offering service on requested pickup or drop address")
                                                }
                                            }
                                        }
                                        if (meteredfare.timebased.length > 0) {
                                            for (let d = 0; d < meteredfare.timebased.length; d++) {
                                                const minTime = meteredfare.timebased[d].distance.split('-')[0];
                                                const maxTime = meteredfare.timebased[d].distance.split('-')[1];
                                                console.log("timebased mintime :", minTime, "timebased maxtim :", maxTime);
                    
                                                if (parseInt(Math.round(time)) >= parseInt(minTime) && parseInt(Math.round(time)) <= parseInt(maxTime)) {
                                                    console.log("timebased mintime NOW:", minTime, "timebased maxtim NOW:", maxTime);
                    
                                                    for (let cus = 0; cus < meteredfare.timebased[d].cusprice.length; cus++) {
                                                        console.log("Start Up Fee", meteredfare.timebased[d].startup);
                                                        console.log("timebased :", {
                                                            segment: meteredfare.timebased[d].cusprice[cus].split('-------')[0],
                                                            price: meteredfare.timebased[d].cusprice[cus].split('-------')[1]
                                                        })
                                                        console.log("after start up fee", parseFloat(meteredfare.timebased[d].cusprice[cus].split('-------')[1]) + parseFloat(meteredfare.timebased[d].startup));
                                                        meteredFareDetails.push({
                                                            sp: pricelist[pl].sp,
                                                            spname: pricelist[pl].spname,
                                                            segment: meteredfare.timebased[d].cusprice[cus].split('-------')[0],
                                                            price: ((parseFloat(meteredfare.timebased[d].cusprice[cus].split('-------')[1] * parseFloat(time))) + parseFloat(meteredfare.timebased[d].startup))
                                                        })
                                                        meteredfaresp.push({
                                                            sp: pricelist[pl].sp,
                                                            segment: meteredfare.timebased[d].spprice[cus].split('-------')[0],
                                                            price: ((parseFloat(meteredfare.timebased[d].spprice[cus].split('-------')[1] * parseFloat(time))) + parseFloat(meteredfare.timebased[d].startup))
                                                        });
                                                    }
                                                } else {
                                                    messages.push("We are not offering service on requested pickup or drop address")
                                                }
                                            }
                                        }
                                    } else {
                                        messages.push("We are not offering service on requested pickup or drop address")
                                    }
                                
                            } else {
                                messages.push("We are not offering service on requested pickup or drop address")
                            }
                        }

                    }
                    result = [];

                    meteredFareDetails.forEach(function(a) {
                        if (!this[a.segment]) {
                            this[a.segment] = {
                                sp: a.sp,
                                spname: a.spname,
                                segment: a.segment,
                                price: 0
                            };
                            result.push(this[a.segment]);
                        }
                        this[a.segment].price += parseInt(a.price);
                    }, Object.create(null));

                    let result2 = [];
                    meteredfaresp.forEach(function(a) {
                        if (!this[a.segment]) {
                            this[a.segment] = {
                                sp: a.sp,
                                segment: a.segment,
                                price: 0
                            };
                            result2.push(this[a.segment]);
                        }
                        this[a.segment].price += parseInt(a.price);
                    }, Object.create(null));

                    // console.log(result);
                    for (let r = 0; r < result.length; r++) {
                        if(spinpl.segments.includes(result[r].segment.toString())){
                            bookings.push(result[r]);
                        }
                    }

                    for (let r = 0; r < result2.length; r++) {
                        if(spinpl.segments.includes(result2[r].segment.toString())){
                            sp.push(result2[r]);
                        }
                    }

                }
            }
            console.log("bookings", bookings)
            const array = bookings;
            const array2 = sp;
            let arrayFiltered = [];
            let arrayFiltered2 = [];
            var uniqueSegments = [];
            var lowPrice = [];
            if (array.length > 0) {
                for (var i = 0; i < array.length; i++) {
                    if (uniqueSegments.indexOf(array[i].segment) === -1) {
                        uniqueSegments.push(array[i].segment);
                        lowPrice.push(array[i]);

                    }

                    for (var j = 0; j < lowPrice.length; j++) {
                        if (lowPrice[j].segment.trim() === array[i].segment.trim()) {

                            if (parseInt(lowPrice[j].price) > parseInt(array[i].price)) {
                                lowPrice[j].price = array[i].price
                            }
                        }

                    }
                }

                arrayFiltered = lowPrice;
            }



            var spArray = [];
            array.forEach(obj => {
                const item = spArray.find(thisItem => thisItem.sp === obj.sp);
                if (item) {
                    if (item.sp > obj.sp)
                        return;
                }

                spArray.push(obj.sp);
            });


            var uniqueSegments2 = [];
            var lowPrice2 = [];
            for (var i = 0; i < array2.length; i++) {
                if (uniqueSegments2.indexOf(array2[i].segment) === -1) {
                    uniqueSegments2.push(array2[i].segment);
                    lowPrice2.push(array2[i]);

                }
                for (var j = 0; j < lowPrice2.length; j++) {
                    if (lowPrice2[j].segment.trim() === array2[i].segment.trim()) {

                        if (parseInt(lowPrice2[j].price) > parseInt(array2[i].price)) {
                            lowPrice2[j].price = array2[i].price
                        }
                    }

                }
            }

            arrayFiltered2 = lowPrice2;

            var dataToSend = [];

            for (var i = 0; i < arrayFiltered.length; i++) {
                const segment = await Segment.findOne({
                    'name': arrayFiltered[i].segment
                });
                console.log(segment);
                dataToSend.push({
                    'segment': arrayFiltered[i].segment,
                    'spname': arrayFiltered[i].spname,
                    'price': arrayFiltered[i].price,
                    'image': segment.image,
                    'pcap': segment.passanger_capacity,
                    'order': segment.Order,
                    'bag': segment.bag,
                })
            }

            var dataToSend2 = [];
            for (var i = 0; i < arrayFiltered2.length; i++) {
                const segment = await Segment.findOne({
                    'name': arrayFiltered2[i].segment
                });
                console.log(segment);
                dataToSend2.push({
                    'segment': arrayFiltered2[i].segment,
                    'price': arrayFiltered2[i].price,
                    'image': segment.image,
                    'spname': "test",
                    'pcap': segment.passanger_capacity,
                    'order': segment.Order,
                    'bag': segment.bag,

                })

            }
            let dataToSend3 = [];

            for (var m = 0; m < messages.length; m++) {
                console.log()
                dataToSend3.push({
                    'segment': messages[m],
                    'price': messages[m],
                    'spname':  messages[m],
                    'image': messages[m],
                    'pcap': messages[m],
                    'order': messages[m],
                    'bag': messages[m],
                })
            }
            console.log("i am here", spArray)
            var dataToSend4 = [];
            if (spArray.length > 0) {


                function onlyUnique(value, index, self) {
                    return self.indexOf(value) === index;
                }

                var uniqueSp = spArray.filter(onlyUnique);
                console.log(uniqueSp[0]);

                const spToSend = await Spmanagement.findById({
                    _id: uniqueSp[0]
                })
                console.log("data to send", spToSend)


                dataToSend4 = [{
                    segment: spToSend._id,
                    price: spToSend.name,
                    image: spToSend.coid,
                    spname:"test",
                    pcap: spToSend.customer,
                    order: "test",
                    bag:"test"
                }];
            }

            

            var finalData = [dataToSend, dataToSend2, dataToSend3, dataToSend4]
            console.log(finalData);

            return finalData;
        }

    },
    attributespcp: async (args) => {
        console.clear();
        console.log(args.sp)
        var sps = await Spmanagement.findById({"_id":args.sp});
        var pricelist = await PriceList.findById({"_id":sps.pricelist});
        console.log(pricelist)
       var attributes = await Attribute.find({"_id":{$in:sps.attributes}});
    //    console.log(attributes)
       var spAttributes = [];
       for(var i = 0; i < attributes.length;i++){
        spAttributes.push(attributes[i].name)
       }
       
        const attributeGroups = await AttributeGroup.find({
            active: "YES",
            _id:{$in:pricelist.attributegroup}
        });
        
        console.log(attributeGroups,"ags");

        var sp = [];
        var spname = [];
        var cp = [];
        var cpname = [];
        for (var i = 0; i < attributeGroups.length; i++) {
            console.log(attributeGroups[i].spprice, attributeGroups[i].cusprice);
            for (var spi = 0; spi < attributeGroups[i].spprice.length; spi++) {
                const name = attributeGroups[i].spprice[spi].split("-------")[0];
                const price = attributeGroups[i].spprice[spi].split("-------")[1];
                if(price !== "")
                sp.push({
                    name: name,
                    price: price
                })
            }


            for (var cpi = 0; cpi < attributeGroups[i].cusprice.length; cpi++) {
                const name = attributeGroups[i].cusprice[cpi].split("-------")[0];
                const price = attributeGroups[i].cusprice[cpi].split("-------")[1];
                if(price !== "")
                cp.push({
                    name: name,
                    price: price
                })
            }
        }
        const arrayFiltered = [];
        sp.forEach(obj => {
            const item = arrayFiltered.find(thisItem => thisItem.name === obj.name);
            if (item) {
                if (item.price > obj.price) {
                    item.price = obj.price;
                }

                return;
            }

            arrayFiltered.push(obj);
        });

        const arrayFiltered2 = [];
        cp.forEach(obj => {
            const item = arrayFiltered2.find(thisItem => thisItem.name === obj.name);
            if (item) {
                if (item.price > obj.price) {
                    item.price = obj.price;
                }

                return;
            }

            arrayFiltered2.push(obj);
        });

        cp = [];
        for (var i = 0; i < arrayFiltered2.length; i++) {
            if(spAttributes.includes(arrayFiltered2[i].name))
                cp.push(arrayFiltered2[i].name + "*" + arrayFiltered2[i].price)
        }

        sp = [];
        for (var i = 0; i < arrayFiltered.length; i++) {
            if(spAttributes.includes(arrayFiltered[i].name))
                sp.push(arrayFiltered[i].name + "*" + arrayFiltered[i].price)
        }

        console.log(cp, sp);
        return {
            cp: cp,
            sp: sp
        }
    },
    filterSpmanagement: async (args) => {
        try {

            let searchresult = [];
            var filter = {};

            var regex = new RegExp(["^", args.name, "$"].join(""), "i");
            if (regex != "/^$/i")
                filter.name = regex;
            if (args.segment != '') {
                var segment = await Segment.findOne({
                    'name': args.segment
                });
                console.log(segment._id);
                filter.segments = segment._id.toString();
            }
            console.log(args.area, args.city);
            if (args.area != '' && args.city != '') {
                var geofencing = await Geofencing.findOne({
                    'area': args.area,
                    city: args.city
                });
                if (geofencing != null) {
                    filter.coveredarea = geofencing._id.toString();
                } else {
                    filter.coveredarea = ''
                }

            } else {
                if (args.area != '') {
                    var geofencing = await Geofencing.findOne({
                        'area': args.area
                    });
                    console.log(geofencing._id, "area");
                    filter.coveredarea = geofencing._id.toString();
                }
                if (args.city != '') {
                    var geofencing = await Geofencing.findOne({
                        'city': args.city
                    });
                    console.log(geofencing._id, "city");
                    filter.coveredarea = geofencing._id.toString();
                }
            }

            console.log(filter);
            searchresult = await Spmanagement.find(filter);

            return searchresult;
        } catch (err) {
            console.log(err);
            throw err;
        }
    },
    AttributeByGroup : async () => {
        const attributeGroups = await AttributeGroup.find({
            active: "YES",
        });
        var sp = [];
        for (var i = 0; i < attributeGroups.length; i++) {
            for (var spi = 0; spi < attributeGroups[i].spprice.length; spi++) {
                const name = attributeGroups[i].spprice[spi].split("-------")[0];
                const price = attributeGroups[i].spprice[spi].split("-------")[1];
                if(sp.indexOf(name) === -1)
                    sp.push(name)
            }
        }

        console.log(sp);
        const attributes = await Attribute.find({name:{$in:sp}});

        return attributes;
    }
};