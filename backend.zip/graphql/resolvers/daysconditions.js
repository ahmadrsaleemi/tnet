indexs = [];
                      if(startDay === 0 && endDay === 6 ){

                        indexs = [0,1,2,3,4,5,6];
                      }
                      if(startDay === 6 && endDay === 0){
                        indexs = [6,0];
                      }


                      if(startDay === 0 && endDay === 5 ){

                        indexs = [0,1,2,3,4,5];
                      }


                      if(startDay === 5 && endDay === 0)
                      {
                        indexs = [5,6,0];
                      }

                      if(startDay === 0 && endDay === 4){

                        indexs = [0,1,2,3,4];
                      }

                      if(startDay === 4 && endDay === 0 )
                      {
                        indexs = [4,5,6,0];
                      }

                      if(startDay === 0 && endDay === 3 ){

                        indexs = [0,1,2,3];
                      }

                      if(startDay === 3 && endDay === 0)
                      {
                        indexs = [3,4,5,6,0];
                      }


                      if(startDay === 0 && endDay === 2 ){

                        indexs = [0,1,2];
                      }

                      if(startDay === 2 && endDay === 0)
                      {
                        indexs = [2,3,4,5,6,0];
                      }

                      if( startDay === 0 && endDay === 1){

                        indexs = [0,1];
                      }


                      if(startDay === 1 && endDay === 0 ){
                        indexs = [1,2,3,4,5,6,0];
                      }

                      if(startDay === 0 && endDay === 0 || startDay === 0 && endDay === 0){

                        indexs = [0];
                      }

                      if( startDay === 1 && endDay === 6){

                        indexs = [1,2,3,4,5,6];
                      }

                      if(startDay === 6 && endDay === 1 ){
                        indexs = [1,0,6];
                      }

                      if(startDay === 1 && endDay === 5){

                        indexs = [1,2,3,4,5];
                      }

                      if(startDay === 5 && endDay === 1 ){
                        indexs = [1,0,6,5];
                      }



                      if( startDay === 1 && endDay === 4){

                        indexs = [1,2,3,4];
                      }

                      if(startDay === 4 && endDay === 1 ){
                        indexs = [1,0,6,5,4];
                      }


                      if(startDay === 1 && endDay === 3){

                        indexs = [1,2,3];
                      }


                      if(startDay === 3 && endDay === 1 ){
                        indexs = [1,0,6,5,4,3];
                      }

                      if( startDay === 1 && endDay === 2){

                        indexs = [1,2];
                      }

                      if(startDay === 3 && endDay === 1 ){
                        indexs = [1,0,6,5,4,3,2];
                      }


                      if(startDay === 1 && endDay === 1){

                        indexs = [1];
                      }





                      if( startDay === 2 && endDay === 6){

                        indexs = [2,3,4,5,6];
                      }


                      if(startDay === 6 && endDay === 2 ){
                        indexs = [6,0,1,2];
                      }

                      if(startDay === 2 && endDay === 5){

                        indexs = [2,3,4,5];
                      }

                      if(startDay === 5 && endDay === 2 ){
                        indexs = [5,0,1,2];
                      }



                      if(startDay === 2 && endDay === 4){

                        indexs = [2,3,4];
                      }

                      if(startDay === 4 && endDay === 2 ){
                        indexs = [4,0,1,2];
                      }

                      if(startDay === 2 && endDay === 3){

                        indexs = [2,3];
                      }

                      if(startDay === 3 && endDay === 2 ){
                        indexs = [3,0,1,2];
                      }

                      if(startDay === 2 && endDay === 2){

                        indexs = [2];
                      }




                      if( startDay === 3 && endDay === 6){

                        indexs = [3,4,5,6];
                      }

                      if(startDay === 6 && endDay === 3 ){
                        indexs = [6,0,1,2,3];
                      }

                      if( startDay === 3 && endDay === 5){

                        indexs = [3,4,5];
                      }

                      if(startDay === 5 && endDay === 3 ){
                        indexs = [5,0,1,2,3];
                      }


                      if( startDay === 3 && endDay === 4){

                        indexs = [3,4];
                      }

                      if(startDay === 4 && endDay === 3 ){
                        indexs = [4,0,1,2,3];
                      }

                      if(startDay === 3 && endDay === 3){

                        indexs = [3];
                      }



                      if( startDay === 4 && endDay === 6){

                        indexs = [4,5,6];
                      }

                      if(startDay === 6 && endDay === 4 ){
                        indexs = [6,0,1,2,3,4];
                      }

                      if(startDay === 4 && endDay === 5){

                        indexs = [4,5];
                      }

                      if(startDay === 5 && endDay === 4 ){
                        indexs = [5,0,1,2,3,4];
                      }


                      if(startDay === 4 && endDay === 4){

                        indexs = [4];
                      }



                      if( startDay === 5 && endDay === 6){

                        indexs = [5,6];
                      }

                      if(startDay === 6 && endDay === 5 ){
                        indexs = [6,0,1,2,3,4,5];
                      }

                      if(startDay === 5 && endDay === 5 ){

                        indexs = [5];
                      }


                      if(startDay === 6 && endDay === 6){

                        indexs = [6];
                      }