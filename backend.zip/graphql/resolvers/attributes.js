const Attribute = require('../../models/Attributes');
const User = require('../../models/user');
const Attributegroup = require('../../models/Attributegroup');
module.exports = {
  Attributes: async () => {
    try {
      const attributes = await Attribute.find();
      return attributes;
    } catch (err) {
      throw err;
    }
  },
  destroyAttribute: async (args) => {
    //return args;
    console.log(args);
    try {
      let  attributes =[];
      attributes = await Attribute.findById({_id:args.recordID}) ;
      
      await Attribute.deleteOne({_id:args.recordID});
      const attributegroup = await Attributegroup.find();
      for(var i = 0 ; i < attributegroup.length;i++){
          let newSp = [] ;
          let newCp = [] ;
          const spprice = attributegroup[i].spprice;
          const custprice = attributegroup[i].cusprice;
          for(var j=0; j < spprice.length;j++){
              if(spprice[j].split("-------")[0] !== attributes.name){
                newSp.push(spprice[j]);
                newCp.push(custprice[j]);
              }
          }
          await Attributegroup.updateMany({'_id': attributegroup[i].id},
            {$set:{
            'spprice': newSp,
            "cusprice":newCp
          }
          },{multi:true});
      }



      console.log(attributes);
     
      return attributes;
    
    } catch (err) {
      throw err;
    }
  },
  Attribute : async (args, req) => {
    try{
    const attributes = await Attribute.findById({_id:args.attributeId}) ;
    return attributes;
    }
    catch (err) {
      console.log(err);
      throw err;
    }
  },
  createAttribute: async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    const attribute = new Attribute({
      name: args.attributeInput.name,
      Order: args.attributeInput.Order,
      date:"2020-02-03T10:41:20.673Z",
      creator: '5e2c16b13e911532b4c22f75'
    });
    let createdAttribute;
    try {
      const result = await attribute.save();
      createdAttribute = result;
      // const creator = await User.findById('5e2c16b13e911532b4c22f75');

      // if (!creator) {
      //   throw new Error('User not found.');
      // }
      // creator.createdEvents.push(segment);
      // await creator.save();

      return createdAttribute;
    } catch (err) {
      console.log(err);
      throw err;
    }
  },
  updateAttribute : async (args, req) => {
    // if (!req.isAuth) {
    //   throw new Error('Unauthenticated!');
    // }
    console.log(args);
    try {
      await Attribute.updateMany({'_id': args.attributeInput.id},
        {$set:{
        'name': args.attributeInput.name,
        "Order":args.attributeInput.Order}
      },{multi:true});

      const attributes = await Attribute.find();
      return attributes;
    } catch (err) {
      console.log(err);
      throw err;
    }
  }
};
