const axios = require('axios');
const Booking = require('../models/bookings');
const SpManagment = require('../models/spmanagment');
const Geofencing =  require('../models/Geofencings');
const fs = require('fs');
var ids = require('../helpers/ids');
const Segment = require('../models/segments');


const stripe = require("stripe")("sk_test_uUt4PcIL7tbMLo9hfcVEb4gs00XnEnI4mE");

const dispatchcount =  async (req,res,next) =>  {
    let searchresult = await Booking.find({status:"pending"});

   res.send(searchresult.length.toString());
}


const bookByCallcenter = async (req, res) => {
  
    // return[];
    const serviceProvider = req.body.servicePName+"-"+req.body.servicePId;
    const serviceprovideDetails = await SpManagment.findById({"_id":req.body.servicePId})
    
    var postData =req.body.postData;
    var attributes = req.body.attributes;
    var newAttributes = [];
      for(var i = 0; i < attributes.length;i++){
        newAttributes.push(attributes[i].split(' ')[0])
      }
      
    var flight = req.body.flight;
    var fromAddress =req.body.from;
    var toAddress =req.body.to;
    let depart = req.body.depart;
    var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    var time = today.getHours() + ":" + today.getMinutes();
    
    console.log(flight,"flight number");
  
    if(depart.indexOf('T') > -1){
      depart = depart.split('T')[0]+" "+time;
    }else{
      depart = req.body.depart;
    }
    console.log(depart,"depart time");
    var segment =req.body.segment;
    var sp =req.body.sp;
    console.log(sp,"sp is here")
    let axiosConfig = {
      headers: {
          'ClientSecret':"1701",
          'ClientId':"EDE6010F-7690-4BAC-8F94-9C30E55EE5F0",
          'Content-Type': 'application/json',
          'Accept':'application/json',
          "Access-Control-Allow-Origin": "*",
      }
    };
  
    var myBookingId = 'AAA001';
  
      var lastRecord = await Booking.find().sort({x:1});
      if(lastRecord.length > 0){
          for(var i=0;i < lastRecord.length;i++){
            var recordArray = lastRecord[i].mybookingid.split('');
          }
          const numberOnly = recordArray[3]+recordArray[4]+recordArray[5];
          const stringOnly = recordArray[0]+recordArray[1]+recordArray[2];
          myBookingId = ids.NumberConcate(ids.nextNumber(numberOnly),stringOnly);
  
      }
    postData.BookingRef = myBookingId;
    postData.CoId = serviceprovideDetails.coid;
    postData.CustomerId = serviceprovideDetails.customer;
    console.log(postData)
    const iVcardo = await axios.post('https://api-ivcardobooking.azurewebsites.net:443/api/Booking/BookNow',postData,axiosConfig)
    console.log(iVcardo.data)
  
    var status = "pending";
    let ivcardoerror ="";
    let assignmentstatus = "pending";
    if(iVcardo.data.Success === true){
      status = "booked";
      assignmentstatus = "confirmed";
    }
    else{
      ivcardoerror = iVcardo.data.Message;
    }
  
    var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!
    var yyyy = today.getFullYear();
    console.log(mm,dd,"month and day")
    if(parseInt(mm) < 10)
        mm = "0"+mm;
    if(parseInt(dd) < 10)
       dd = "0"+dd;
    console.log(mm,dd,"month and day")
    
    today = yyyy + '-' + mm + '-' + dd;
    var pname='';
    var pphone=0;
    // console.log(fromAddress,toAddress)
    
     let boobking_id = iVcardo.data.Data ? iVcardo.data.Data : 00000;
    for(var i=0;i < postData.Passengers.length;i++){
      pname = postData.Passengers[i].pName;
      pphone = postData.Passengers[i].pPhone;
    }
    var currentDate = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    const booking = new Booking({
                from: fromAddress,
                to: toAddress,
                depart: depart,
                name: pname,
                cellphone:pphone,
                segment:segment,
                sp:sp ? sp : 0,
                newsp:req.body.sp ? req.body.sp : 0,
                cp:segment.split("-")[1],
                created_at:today+"  "+time,
                date:depart.split(' ')[0],
                time:depart.split(' ')[1],
                booking_id:boobking_id,
                serviceprovide:serviceProvider,
                status:status,
                mybookingid:myBookingId,
                bookingfrom:"callcenter",
                attributes:attributes,
                flight : flight,
                postdata:[postData],
                creator: '5e2c16b13e911532b4c22f75',
                ivcardoerror:ivcardoerror,
                assignmentstatus:assignmentstatus
              });
              await booking.save();
  
              const smsData = {
                "to": pphone,
                "from": "46708885550",
                "twoway": true,
                "message": "Booking Confirmed \nBooking Ref: "+myBookingId+" \nPickup Date: "+depart.split(' ')[0]+" at "+depart.split(' ')[1]+" \nPickup: "+fromAddress+"\n",
                "conversation": "",
                "username": "techcellance",
                "password": "j3CrL!Vy^vVo74",
                "apikey": "string",
                "costcenter": "string",
                "flash": true,
                "validminutes": "string",
                "defaultcountrycode": "string",
                "replacecharacters": true
              }
        const lekab = await axios.post('https://secure.lekab.com/restsms/lekabrest/send/single',smsData)
        simage='';
        var segments =  await Segment.findOne({name:segment.split('-')[0]})
        // writeFile function with filename, content and callback function
        fs.appendFile('logs/booking-log.txt',"Booking Request from Call Center at  "+today+" : "+time+"\n"+JSON.stringify(postData)+"\n Response for callcenter at  "+today+" : "+time+"\n"+JSON.stringify(iVcardo.data)+"\n"+"\n", function (err) {
          if (err) throw err;
            console.log("file saved")
        });
  
        fs.appendFile('logs/sms-log.txt',"call center  "+today+" : "+time+"\n"+JSON.stringify(smsData)+"\n Response : "+JSON.stringify(lekab.data)+"\n"+"\n", function (err) {
          if (err) throw err;
            console.log("file saved")
        });
        res.json({Success:iVcardo.data.Success,booking_id:boobking_id,Data:myBookingId,depart:depart,image:segments.image})
  
    
}

const cancelByCallcenter =  async (req,res,next) => {

    const booking = await Booking.findOne({booking_id:req.body.booking_id});
    var postData ={
      "BookingID": req.body.booking_id,
      "UserID": 0,
      "Reason": booking.mybookingid
    };
  
    let axiosConfig = {
      headers: {
          'ClientSecret':"1701",
          'ClientId':"EDE6010F-7690-4BAC-8F94-9C30E55EE5F0",
          'Content-Type': 'application/json',
          'Accept':'application/json',
          "Access-Control-Allow-Origin": "*",
      }
    };
    const today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    var todayTime = today.getHours() + ":" + today.getMinutes();
    var dd = today.getDate();
    var mm = today.getMonth() +1; //January is 0!
    var yyyy = today.getFullYear();
    console.log(mm,dd,"month and day")
      if(parseInt(mm) < 10)
          mm = "0"+mm;
      if(parseInt(dd) < 10)
         dd = "0"+dd;
    console.log(mm,dd,"month and day")
  
    var todday = yyyy + '-' + mm + '-' + dd;
  
    var currentDate = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    const sp = booking.serviceprovide.split('-')[1].toString();
    const time = booking.time;
    const date = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    const spp = await SpManagment.findById({_id:sp})
    const cancelTime =parseInt(spp.cancelationtime);
    var dt = new Date(booking.depart);
    dt.setMinutes ( dt.getMinutes() - cancelTime );
      const responce = await axios.post('https://api-ivcardobooking.azurewebsites.net:443/api/Booking/CancelBooking', postData,axiosConfig);
      // console.log(responce,"respons")
      if(responce.data.Success){
        var myquery = {'booking_id':req.body.booking_id};
        var newvalues = { $set: {status:'canceled',assignmentstatus:"Cancelled Confirmed",canceltime:todday+" : "+todayTime } };
        await Booking.updateOne(myquery, newvalues, function(err, res) {
          if (err) throw err;
          console.log("1 document updated");
        });
  
        if(currentDate < dt ){
          console.log("cancel time is less then time")
          if(booking.bookingfrom === "tnet"){
              stripe.checkout.sessions.retrieve(booking.session,
                async (err, session) => {
                console.log(session.payment_intent,"data")
                const refund = await stripe.refunds.create({
                    payment_intent: session.payment_intent,
                  });
                  stripe.paymentIntents.retrieve(
                    session.payment_intent,
                    function(err, paymentIntent) {
                       if(paymentIntent){
                          fs.appendFile('logs/payment.txt',"Request  For Callcenter Refund At "+todday+"   "+todayTime+"\n"+JSON.stringify(paymentIntent)+"\n"+"\n", function (err) {
                            if (err) throw err;
                              console.log("file saved")
      
                              fs.appendFile('logs/payment.txt',"Response Callcenter Refund At "+todday+"   "+todayTime+"\n"+JSON.stringify(refund)+"\n"+"\n", function (err) {
                                if (err) throw err;
                                  console.log("file saved")
                              });
                          });
                       }
                    }
                  );
                }
              );
          }  
          }
  
          fs.appendFile('logs/booking-log.txt',"Cancellation Requestion from Call Center at  "+todday+"   "+todayTime+"\n"+JSON.stringify(postData)+"\nResponse for callcenter at "+todday+" "+todayTime+"\n"+JSON.stringify(responce.data)+"\n"+"\n", function (err) {
            if (err) throw err;
              console.log("file saved")
          });
          const smsData = {
            "to": booking.cellphone,
            "from": "46708885550",
            "twoway": true,
            "message": "Booking Cancelled \nBooking Ref: "+booking.mybookingid+" \nPickup Date: "+booking.date+" at "+booking.time+" \nPickup: "+booking.from+"\n",
            "conversation": "",
            "username": "techcellance",
            "password": "j3CrL!Vy^vVo74",
            "apikey": "string",
            "costcenter": "string",
            "flash": true,
            "validminutes": "string",
            "defaultcountrycode": "string",
            "replacecharacters": true
          }
          const lekab = await axios.post('https://secure.lekab.com/restsms/lekabrest/send/single',smsData)
          fs.appendFile('logs/sms-log.txt',"call center  "+todday+" : "+todayTime+"\n"+JSON.stringify(smsData)+"\n Response : "+JSON.stringify(lekab.data)+"\n"+"\n", function (err) {
            if (err) throw err;
              console.log("file saved")
          });
          res.json(responce.data)
      }
}

const confirmCancel = async (req,res,next) =>
{
    const booking = await Booking.findOne({booking_id:req.body.booking_id});
    const sp = booking.serviceprovide.split('-')[1].toString();
    const spp = await SpManagment.findById({_id:sp})
    const cancelTime =parseInt(spp.cancelationtime);
    var currentDate=new Date();
    var dt = new Date(booking.depart);
    dt.setMinutes ( dt.getMinutes() - cancelTime );
    console.log(
      currentDate.getFullYear()+"-"+(parseInt(currentDate.getMonth())+1)+"-"+currentDate.getDate()+" "+currentDate.getHours()+" : "+currentDate.getMinutes()
      // +"\n",booking.depart
      +"\n",dt.getFullYear()+"-"+(parseInt(dt.getMonth())+1)+"-"+dt.getDate()+" "+dt.getHours()+" : "+dt.getMinutes()
      +"\n",cancelTime
    )
    if(currentDate > dt ){
      res.json({error:"The cancellation time has passed for this Booking, there would be no refund after cancellation"})
      console.log("The cancellation time has passed for this Booking, there would be no refund after cancellation")
    }
    else{
      res.json({error:""})
    }
}

const bookingByTnet =  async (req,res,next) => {
    const bookings = await Booking.findOne({mybookingid:req.body.booking_id});
    const spId = bookings.serviceprovide.split('-')[1];
    const spName = bookings.serviceprovide.split('-')[0];
    const sp = await SpManagment.findById({"_id":spId});
    
    var spCTime = parseInt(sp.cancelationtime);
    let hours = bookings.time.split(":")[0]*60;
    let minutes = bookings.time.split(":")[1];
  
    // var d1 = new Date (bookings.depart);
    var d2 = new Date ( bookings.depart );
    d2.setMinutes ( d2.getMinutes() - spCTime );
  
    var todayTime = d2.getHours() + ":" + d2.getMinutes();
    var dd = String(d2.getDate()).padStart(2, '0');
    var mm = String(d2.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = d2.getFullYear();
   
    
    var todday = yyyy + '-' + mm + '-' + dd;
    var cancellationTime =todday+"  "+todayTime;
    var booking = {
      "session": bookings.session,
      "attributes": bookings.attributes,
      "booking_id": bookings.booking_id,
      "bookingfrom": bookings.bookingfrom,
      "cellphone": bookings.cellphone,
      "created_at": bookings.created_at,
      "creator": bookings.creator,
      "date": bookings.date,
      "depart": bookings.depart,
      "from": bookings.from,
      "mybookingid": bookings.mybookingid,
      "name": bookings.name,
      "segment": bookings.segment.split('-')[0],
      "segmentprice": bookings.segment.split('-')[1],
      "cp": bookings.cp,
      "serviceprovide": spName,
      "sp": bookings.sp,
      "status":bookings.status,
      "time": bookings.time,
      "to": bookings.to,
      "flight": bookings.flight,
      "_id":  bookings._id,
      "cancellationtime":cancellationTime,
      "refund":bookings.refund,
      "postdata":bookings.postdata,
      "canceltime":bookings.canceltime,
      "assignmentstatus":bookings.assignmentstatus

    }
  
    res.json(booking)
  
}

const cancelByTnet = async (req,res,next) => {
    console.log("working")
    const booking = await Booking.findOne({booking_id:req.body.booking_id});
    console.log(booking);
    var postData ={
      "BookingID": req.body.booking_id,
      "UserID": 0,
      "Reason": booking.mybookingid
    };

    let axiosConfig = {
      headers: {
          'ClientSecret':"1701",
          'ClientId':"EDE6010F-7690-4BAC-8F94-9C30E55EE5F0",
          'Content-Type': 'application/json',
          'Accept':'application/json',
          "Access-Control-Allow-Origin": "*",
      }
    };
    
    const sp = booking.serviceprovide.split('-')[1].toString();
    const time = booking.time;
    const date = booking.depart;
    const spp = await SpManagment.findById({_id:sp})

    const today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    const cancelTime =parseInt(spp.cancelationtime);
    var currentDate=new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));

    var dt = new Date(booking.depart);
    dt.setMinutes ( dt.getMinutes() - cancelTime );
    var todayTime = today.getHours() + ":" + today.getMinutes();
    var dd = today.getDate();
    var mm = today.getMonth() +1; //January is 0!
    var yyyy = today.getFullYear();
    var todday = yyyy + '-' + mm + '-' + dd;
    axios.post('https://api-ivcardobooking.azurewebsites.net:443/api/Booking/CancelBooking', postData,axiosConfig)
      .then((responce) => {
       
        if(responce.data.Success){
            var myquery = {'booking_id':req.body.booking_id};
            var newvalues = { $set: {status:'canceled',assignmentstatus:"Cancelled Confirmed",canceltime:todday+" : "+todayTime } };
            Booking.updateOne(myquery, newvalues, function(err, res) {
              if (err) throw err;
              console.log("1 document updated 2");
            });
            fs.appendFile('logs/booking-log.txt',"Cancellation Requestion from Tnet Web App at "+todday+"  "+todayTime+"\n"+JSON.stringify(postData)+"\n"+"Response for tnet at "+todday+"  "+todayTime+"\n"+JSON.stringify(responce.data)+"\n"+"\n", function (err) {
              if (err) throw err;
                console.log("file saved")
            });
            res.json(responce.data)
        }
        
      })
      .catch((err) => {
        console.log("AXIOS ERROR: ", err);
      })
      if(currentDate < dt)
      { 
        if(booking.bookingfrom === "tnet"){

          stripe.checkout.sessions.retrieve(booking.session,
            async (err, session) => {
            if(err){
              console.log(err)
            }
            else{
              console.log(session.payment_intent,"data")
              const refund = await stripe.refunds.create({
                  payment_intent: session.payment_intent
                });
                stripe.paymentIntents.retrieve(
                  session.payment_intent,
                  function(err, paymentIntent) {
                     if(paymentIntent){
                        fs.appendFile('payment.txt',"Request  For Tnet Refund At "+todday+"   "+todayTime+"\n"+JSON.stringify(paymentIntent)+"\n"+"\n", function (err) {
                          if (err) throw err;
                            console.log("file saved")
    
                            fs.appendFile('payment.txt',"Response Tnet Refund At "+todday+"   "+todayTime+"\n"+JSON.stringify(refund)+"\n"+"\n", function (err) {
                              if (err) throw err;
                                console.log("file saved")
                            });
                        });
                     }
                  }
                );
                
                
            }
             
            }
          );



         
        }
      }
      const smsData = {
        "to": booking.cellphone,
        "from": "46708885550",
        "twoway": true,
        "message": "Booking Cancelled \nBooking Ref: "+booking.mybookingid+" \nPickup Date: "+booking.date+" at "+booking.time+" \nPickup: "+booking.from+"\n",
        "conversation": "",
        "username": "techcellance",
        "password": "j3CrL!Vy^vVo74",
        "apikey": "string",
        "costcenter": "string",
        "flash": true,
        "validminutes": "string",
        "defaultcountrycode": "string",
        "replacecharacters": true
      }
      const lekab = await axios.post('https://secure.lekab.com/restsms/lekabrest/send/single',smsData)
      fs.appendFile('logs/sms-log.txt',"tnet  "+todday+" : "+todayTime+"\n"+JSON.stringify(smsData)+"\n Response : "+JSON.stringify(lekab.data)+"\n"+"\n", function (err) {
        if (err) throw err;
          console.log("file saved")
      });
}

const refund =  async (req,res,next) => {
    var booking = req.body.booking;
    var ramount =  req.body.ramount;
    var rsp = req.body.rsp;
    var rdescription = req.body.rdescription;
    var dbBooking = await Booking.findOne({"mybookingid":booking.mybookingid});
    var segment = dbBooking.segment;
    var cp = dbBooking.cp;
    var sp=dbBooking.sp;
    console.log(cp,ramount)
    // return 
    console.log(cp,"cp",booking.segmentprice)
    var refundAmount = req.body.sumOfSpCp;
  
    var updatedCp = parseInt(cp) - parseInt(ramount)
    // var updatedSp = parseInt(sp) - parseInt(rsp)
    var updatedSp =parseInt(rsp)
    var refundData = booking.refund;
    const today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    var todayTime = today.getHours() + ":" + today.getMinutes();
    var dd = today.getDate();
    var mm = today.getMonth() +1; //January is 0!
    var yyyy = today.getFullYear();
    if(parseInt(mm) < 10)
        mm = "0"+mm;
    if(parseInt(dd) < 10)
        dd = "0"+dd;
    var todday = yyyy + '-' + mm + '-' + dd;
  
    refundData.push({"date":todday+" "+todayTime,"amount":ramount,"sp":rsp,"description":rdescription})
  
    if(booking.bookingfrom === "callcenter"){
      const result = await Booking.updateOne({'_id': booking._id},
          {$set:{
          'refund': refundData,
          'cp':updatedCp,
          'newsp':updatedSp
        }
        },{multi:true});
        res.json({Success:"done"})
    }
    else if(booking.bookingfrom === "tnet"){
      const result = await Booking.updateOne({'_id': booking._id},
          {$set:{
          'refund': refundData,
          'cp':updatedCp,
          'newsp':updatedSp
        }
        },{multi:true});
  
        stripe.checkout.sessions.retrieve(booking.session,
          async (err, session) => {
          if(err){
            console.log(err)
          }
          else{
            console.log(session.payment_intent,"data")
            const refund = await stripe.refunds.create({
                payment_intent: session.payment_intent,
                amount:refundAmount*100
              });
              stripe.paymentIntents.retrieve(
                session.payment_intent,
                function(err, paymentIntent) {
                   if(paymentIntent){
                      fs.appendFile('logs/payment.txt',"Request  For callcenter Refund At "+todday+"   "+todayTime+"\n"+JSON.stringify(paymentIntent)+"\n"+"\n", function (err) {
                        if (err) throw err;
                          console.log("file saved")
  
                          fs.appendFile('logs/payment.txt',"Response callcenter Refund At "+todday+"   "+todayTime+"\n"+JSON.stringify(refund)+"\n"+"\n", function (err) {
                            if (err) throw err;
                              console.log("file saved")
                          });
                      });
                   }
                }
              );
              
              
          }
           
          }
        );
        res.json({Success:"done"})
    }
    else{
      res.json({Success:"faild"})
    }
    
}

const dispatchmultiple = async(req,res,next) => {
    var bookingIds = req.body.booking;

    // console.log(bookingIds);
    var booking = await Booking.find({mybookingid:{$in:bookingIds}})
    
    if(booking.length  > 0)
    {
        
        for(var i=0; i < booking.length ;i++){
            // console.log(booking.length)
            var spmanagment = booking[i].serviceprovide;
            var sp = await SpManagment.findById({_id:spmanagment.split('-')[1]})
           
            var coid = sp.coid;
            var CustomerId = sp.customer;
            console.log(coid,CustomerId,"sp coid and customer id");
            var postData = booking[i].postdata[0];
            postData.CoId = coid;
            postData.CustomerId = CustomerId;
            console.log(postData.CoId,postData.CustomerId,"booking coid and customer id")
            
            var postData = booking[i].postdata[0];
            var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
            var time = today.getHours() + ":" + today.getMinutes();
            var dd = today.getDate();
            var mm = today.getMonth() +1; //January is 0!
            var yyyy = today.getFullYear();
            today = yyyy + '-' + mm + '-' + dd;
            
            let axiosConfig = {
            headers: {
                'ClientSecret':"1701",
                'ClientId':"EDE6010F-7690-4BAC-8F94-9C30E55EE5F0",
                'Content-Type': 'application/json',
                'Accept':'application/json',
                "Access-Control-Allow-Origin": "*",
            }
            };
            const iVcardo = await axios.post('https://api-ivcardobooking.azurewebsites.net:443/api/Booking/BookNow', postData,axiosConfig)
            console.log(iVcardo.data)
            if(iVcardo.data.Success === true){
            await Booking.updateMany({'_id': booking[i]._id},
                {$set:{
                'status': "booked",
                'assignmentstatus': "Confirmed",
                "booking_id":iVcardo.data.Data
            }
            },{multi:true});

            const smsData = {
                "to": booking[i].cellphone,
                "from": "46708885550",
                "twoway": true,
                "message": "Booking Confirmed \nBooking Ref: "+booking[i].myBookingId+" \nPickup Date: "+booking[i].depart.split(' ')[0]+" at "+booking[i].depart.split(' ')[1]+" \nPickup: "+booking[i].from+"\n",
                "conversation": "",
                "username": "techcellance",
                "password": "j3CrL!Vy^vVo74",
                "apikey": "string",
                "costcenter": "string",
                "flash": true,
                "validminutes": "string",
                "defaultcountrycode": "string",
                "replacecharacters": true
            }
            const lekab = await axios.post('https://secure.lekab.com/restsms/lekabrest/send/single',smsData)
            
            fs.appendFile('logs/sms-log.txt',"call center  "+today+" : "+time+"\n"+JSON.stringify(smsData)+"\n Response : "+JSON.stringify(lekab.data)+"\n"+"\n", function (err) {
              if (err) throw err;
                  console.log("file saved")
              });
        }
          fs.appendFile('logs/booking-log.txt',"Booking Request from Call Center at  "+today+" : "+time+"\n"+JSON.stringify(postData)+"\n Response : "+JSON.stringify(iVcardo.data)+"\n"+"\n", function (err) {
            if (err) throw err;
                console.log("file saved")
            });

         
        }   
    }
    res.json({Success:true})
}


const changeStatus = async(req,res,next) => {
    var bookingId = req.body.booking_id;
    var status = req.body.status;
    var spref = req.body.spref;
    var update = await Booking.updateOne({'mybookingid': bookingId},
                {$set:{
                'assignmentstatus':status,
                'booking_id':spref
    }})
    res.json({Success:true})
}

 module.exports = {
    dispatchcount,
    bookByCallcenter,
    cancelByCallcenter,
    confirmCancel,
    bookingByTnet,
    cancelByTnet,
    refund,
    dispatchmultiple,
    changeStatus
 };