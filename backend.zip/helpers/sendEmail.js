const axios = require('axios');
var nodemailer = require('nodemailer');


function contactUs(req,res,next) {

    var body =  req.body.data;
    let transport = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
          user: '',
          pass: ''
        }
    });
    
    const message = {
        from: body.email, // Sender address
        to: 'adeelbajwa786@gmail.com',         // List of recipients
        subject: body.subject, // Subject line
        html: " <b> Name </b> : "+body.name+"<br />"+" <b> Number </b> : "+body.number+"<br />"+" <b> Message </b> : "+body.message, // Plain text body
        replyTo:body.email,
    };
    transport.sendMail(message, function(err, info) {
        if (err) {
          console.log(err)
        } else {
          console.log(info);
        }
    });
    res.send("done");
}

function complaints(req,res,next) {

    var body =  req.body.data;
    let transport = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
          user: '',
          pass: ''
        }
    });
    
    const message = {
        from: body.email, // Sender address
        to: 'adeelbajwa786@gmail.com',         // List of recipients
        subject: body.cause, // Subject line
        html: " <b> Name </b> : "+body.name+"<br />"+" <b> Number </b> : "+body.number+"<br />"+" <b> Message </b> : "+body.description, // Plain text body
        replyTo:body.email,
    };

    transport.sendMail(message, function(err, info) {
        if (err) {
          console.log(err)
        } else {
          console.log(info);
        }
    });
    res.send("done");
}


function becomeadriver(req,res,next) {

    var body =  req.body.data;
    let transport = nodemailer.createTransport({
        service: 'Gmail',
        auth: {
          user: '',
          pass: ''
        }
    });
    
    const message = {
        from: body.email, // Sender address
        to: 'adeelbajwa786@gmail.com',         // List of recipients
        subject: body.name + " Wants to be the driver", // Subject line
        html: " <b> Name </b> : "+body.name+"<br />"+" <b> Number </b> : "+body.number+"<br />", // Plain text body
        replyTo:body.email,
    };

    transport.sendMail(message, function(err, info) {
        if (err) {
          console.log(err)
        } else {
          console.log(info);
        }
    });
    res.send("done");
}



 module.exports = {
    contactUs,
    complaints,
    becomeadriver
 };