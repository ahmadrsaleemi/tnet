const express = require('express');
const bodyParser = require('body-parser');
const graphqlHttp = require('express-graphql');
const mongoose = require('mongoose');
const graphQlSchema = require('./graphql/schema/index');
const graphQlResolvers = require('./graphql/resolvers/index');
const isAuth = require('./middleware/is-auth');
const http = require('http');
const axios = require('axios');
const Booking = require('./models/bookings');
const SpManagment = require('./models/spmanagment');
const Geofencing =  require('./models/Geofencings');
const stripe = require("stripe")("sk_test_uUt4PcIL7tbMLo9hfcVEb4gs00XnEnI4mE");
var multer = require('multer')
const Segment = require('./models/segments');
var ids = require('./helpers/ids');
var sendEmail = require('./helpers/sendEmail');
var bookingController = require('./controllers/booking');
var fs = require('fs');

process.env.TZ = 'Europe/Stockholm';
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
  cb(null, './images');
},

filename: function (req, file, cb) {
  cb(null,file.originalname )
}
})

console.log(new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' })))


var upload = multer({ storage: storage }).single('file');


const app = express();
app.use(bodyParser.json({limit: '50mb'}));
app.use(bodyParser.urlencoded({
  extended: true,
  limit: '50mb'
}));



app.use(function(req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", '*');
    res.setHeader("Access-Control-Allow-Credentials", true);
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
    res.setHeader("Access-Control-Allow-Headers", 'Authorization,Origin,X-Requested-With,Content-Type');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
});

app.use(isAuth);
app.use(express.static('images'));

app.post('/upload',function(req, res) {
  console.log("working");
  upload(req, res, function (err) {
     if (err instanceof multer.MulterError) {
         return res.status(500).json(err)
     } else if (err) {
         return res.status(500).json(err)
     }
    if(req.file!== undefined){
      var myquery = { _id: req.body.id };
      var newvalues = { $set: {image: "http://"+req.headers.host+"/"+req.file.filename } };

      Segment.updateOne(myquery, newvalues, function(err, res) {
        if (err) throw err;
        console.log("1 document updated");
      });
    }
    
    
return res.status(200).send(req.file)

})

});

app.post('/updatecoord',async (req,res,next) =>{
const result = await Geofencing.update({'_id': req.body.id},
    {$set:{
    "coordinates":req.body.coordinates
  }
  },{multi:true});
  if(result){
    res.send("true")
  }else{
    res.send("false")
  }
  
})

app.post('/',bookingController.bookByCallcenter)

app.post('/cancel',bookingController.cancelByCallcenter)

app.post('/confirmcancel',bookingController.confirmCancel)


app.post('/booking',bookingController.bookingByTnet)

app.post('/cancelfromtnet',bookingController.cancelByTnet)

app.post('/refund',bookingController.refund)

app.post('/dispatch',async(req,res,next) => {
    var booking = req.body.booking;
    var postData = booking.postdata[0];
    var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
    var time = today.getHours() + ":" + today.getMinutes();
    var dd = today.getDate();
    var mm = today.getMonth() +1; //January is 0!
    var yyyy = today.getFullYear();
    today = yyyy + '-' + mm + '-' + dd;
    
    let axiosConfig = {
      headers: {
          'ClientSecret':"1701",
          'ClientId':"EDE6010F-7690-4BAC-8F94-9C30E55EE5F0",
          'Content-Type': 'application/json',
          'Accept':'application/json',
          "Access-Control-Allow-Origin": "*",
      }
    };
    const iVcardo = await axios.post('https://api-ivcardobooking.azurewebsites.net:443/api/Booking/BookNow', postData,axiosConfig)
    console.log(iVcardo.data,"data")
    if(iVcardo.data.Success === true){
      console.log(iVcardo.data.Data,"data");
    await Booking.updateMany({'_id': booking._id},
        {$set:{
        'status': "booked",
        'booking_id': iVcardo.data.Data
      }
      },{multi:true});

      const smsData = {
        "to": booking.cellphone,
        "from": "46708885550",
        "twoway": true,
        "message": "Booking Confirmed \nBooking Ref: "+booking.myBookingId+" \nPickup Date: "+booking.depart.split(' ')[0]+" at "+booking.depart.split(' ')[1]+" \nPickup: "+booking.from+"\n",
        "conversation": "",
        "username": "techcellance",
        "password": "j3CrL!Vy^vVo74",
        "apikey": "string",
        "costcenter": "string",
        "flash": true,
        "validminutes": "string",
        "defaultcountrycode": "string",
        "replacecharacters": true
      }
      const lekab = await axios.post('https://secure.lekab.com/restsms/lekabrest/send/single',smsData)
      fs.appendFile('logs/booking-log.txt',"Booking Request from Call Center at  "+today+" : "+time+"\n"+JSON.stringify(postData)+"\n Response : "+JSON.stringify(iVcardo.data)+"\n"+"\n", function (err) {
      if (err) throw err;
        console.log("file saved")
      });

      fs.appendFile('logs/sms-log.txt',"call center  "+today+" : "+time+"\n"+JSON.stringify(smsData)+"\n Response : "+JSON.stringify(lekab.data)+"\n"+"\n", function (err) {
      if (err) throw err;
        console.log("file saved")
      });
      res.json({Success:"done"})
  }
})


app.post('/create_payement',async(req,res,next) =>{

  console.log(req.body);
  var attributes = req.body.attributes;
  const serviceProvider = req.body.servicePName+"-"+req.body.servicePId;
  var myBookingId = 'AAA001';
  var lastRecord = await Booking.find().sort({x:1});
  if(lastRecord.length > 0){
      for(var i=0;i < lastRecord.length;i++){
        var recordArray = lastRecord[i].mybookingid.split('');
      }
      const numberOnly = recordArray[3]+recordArray[4]+recordArray[5];
      const stringOnly = recordArray[0]+recordArray[1]+recordArray[2];
      myBookingId = ids.NumberConcate(ids.nextNumber(numberOnly),stringOnly);
  }
  var postData =req.body.postData;
  postData.BookingRef = myBookingId;
  console.log(postData);
  var fromAddress =req.body.from;
  var toAddress =req.body.to;
  var depart =req.body.depart;
  var flight = req.body.flight;
  var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
  var time = today.getHours() + ":" + today.getMinutes();
  var dd = today.getDate();
  var mm = today.getMonth() +1; //January is 0!
  var yyyy = today.getFullYear();
  console.log(mm,dd,"month and day")
    if(parseInt(mm) < 10)
        mm = "0"+mm;
    if(parseInt(dd) < 10)
       dd = "0"+dd;
  console.log(mm,dd,"month and day")
  
  var todday = yyyy + '-' + mm + '-' + dd;

  if(depart.indexOf('T') > -1){
    depart = depart.split('T')[0]+" "+time;
  }else{
    console.log("i am here")
    depart = req.body.depart;
  }

  var pname='';
  var pphone=0;
  for(var i=0;i < postData.Passengers.length;i++){
    pname = postData.Passengers[i].pName;
    pphone = postData.Passengers[i].pPhone;
  }
  var segment =req.body.cp;
  const product = await stripe.products.create({
    name: segment.split("-")[0],
  });
  console.log(product.id)
  const price = await stripe
  .prices
  .create({
    product:product.id,
    unit_amount: parseInt(segment.split("-")[1])*100,
    currency: 'SEK',
  });
  
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    line_items: [{
      price:price.id,
      quantity: 1,
    }],
    mode: 'payment',
    success_url: 'http://localhost:3001/success?session_id={CHECKOUT_SESSION_ID}',
    cancel_url: 'http://localhost:3001/cancel',
  });
  const booking = new Booking({
      from: fromAddress,
      to: toAddress,
      depart: depart,
      name: pname,
      cellphone:pphone,
      segment:req.body.cp,
      created_at:todday+"  "+time,
      date:depart.split(' ')[0],
      booking_id:"NONE",
      status:'booked',
      sp:req.body.sp ? req.body.sp : 0,
      newsp:req.body.sp ? req.body.sp : 0,
      cp:segment.split("-")[1],
      mybookingid:myBookingId,
      serviceprovide:serviceProvider,
      time:depart.split(' ')[1],
      bookingfrom:"tnet",
      session:session.id,
      creator: '5e2c16b13e911532b4c22f75',
      flight:flight,
      postdata:postData,
      attributes:attributes
  });
  booking.save();
  // console.log(session.id)
  // // cs_test_l1bnHkTrXjtcOYoYJ3wavS54dYPrLDIAdiZ3CMTVMtLipzWearEpPaIa
  res.json(session);
})


app.post("/bookingbysession", async(req,res,next) => {
    const { sessionId } = req.body;
    const bookings = await Booking.findOne({"session":sessionId,booking_id:"NONE"});
    if(bookings){
         var postData = bookings.postdata[0];
        // var postData = [];
        let axiosConfig = {
          headers: {
              'ClientSecret':"1701",
              'ClientId':"EDE6010F-7690-4BAC-8F94-9C30E55EE5F0",
              'Content-Type': 'application/json',
              'Accept':'application/json',
              "Access-Control-Allow-Origin": "*",
          }
        };

        let status = "booked";
        let assignmentstatus = "pending";
        let ivcardoerror ="";
        const iVcardo = await axios.post('https://api-ivcardobooking.azurewebsites.net:443/api/Booking/BookNow', postData,axiosConfig)
        console.log(postData,iVcardo.data,"data and response")

        if(iVcardo.data.Success === true){
          status = "booked";
          assignmentstatus ="confirmed";
        }
        else{
          ivcardoerror = iVcardo.data.Message;
        }
        
        console.log(ivcardoerror,"ivcardoerror")
        const newBooking =  await Booking.updateOne({'_id': bookings._id},
              {$set:{
              'status': status,
              "booking_id":iVcardo.data.Data ? iVcardo.data.Data : 0,
              "ivcardoerror":ivcardoerror,
              "assignmentstatus":assignmentstatus
            }
          },{multi:true});
        var today = new Date(new Date().toLocaleString('en-US',{ timeZone: 'Europe/Stockholm' }));
        var time = today.getHours() + ":" + today.getMinutes();
        var dd = today.getDate();
        var mm = today.getMonth() +1; //January is 0!
        var yyyy = today.getFullYear();
        var todday = yyyy + '-' + mm + '-' + dd;
        const smsData = {
          "to": bookings.cellphone,
          "from": "46708885550",
          "twoway": true,
          "message": "Booking Confirmed \nBooking Ref: "+bookings.mybookingid+" \nPickup Date: "+bookings.date+" at "+bookings.time+" \nPickup: "+bookings.from+"\n",
          "conversation": "",
          "username": "techcellance",
          "password": "j3CrL!Vy^vVo74",
          "apikey": "string",
          "costcenter": "string",
          "flash": true,
          "validminutes": "string",
          "defaultcountrycode": "string",
          "replacecharacters": true
        }
        const lekab = await axios.post('https://secure.lekab.com/restsms/lekabrest/send/single',smsData)
        fs.appendFile('logs/sms-log.txt',"tnet  "+todday+" : "+time+"\n"+JSON.stringify(smsData)+"\n Response : "+JSON.stringify(lekab.data)+"\n"+"\n", function (err) {
          if (err) throw err;
            console.log("file saved")
        });
        fs.appendFile('logs/booking-log.txt',"Booking Request from Tnet Web App  at  "+todday+" : "+time+"\n"+JSON.stringify(postData)+"\n Response for tnet at  "+todday+" : "+time+"\n"+JSON.stringify(iVcardo.data)+"\n"+"\n", function (err) {
          if (err) throw err;
            console.log("file saved")
        });
        fs.appendFile('logs/payment.txt',"Request For Tnet Web App  "+todday+" : "+time+"\n"+JSON.stringify({
          amount: parseInt(bookings.cp)*100,
          currency: 'SEK',
          source: 'tok_amex',
          description: 'Booking has been done against '+bookings.mybookingid,
        })+"\n"+"\n", function (err) {
          if (err) throw err;
            console.log("file saved")
        }); 

        stripe.checkout.sessions.retrieve(sessionId,
          async (err, session) => {
          if(err){
            console.log(err)
          }
          else{
              stripe.paymentIntents.retrieve(
                session.payment_intent,
                function(err, paymentIntent) {
                   if(paymentIntent){
                      fs.appendFile('logs/payment.txt',"Respnse For Tnet Web App  "+todday+" : "+time+"\n"+JSON.stringify(paymentIntent)+"\n"+"\n", function (err) {
                        if (err) throw err;
                          console.log("file saved")
                      });
                   }
                }
              );
              
              
          }
           
          }
        );
        
        const newbooking =await Booking.findOne({"session" : sessionId});
        res.json({newbooking})
      }
      else{
        const newbooking = await Booking.findOne({ "session":sessionId});
        res.json({newbooking})
      }
})

app.post("/changestatus",bookingController.changeStatus)
app.post("/dispatchmultiple",bookingController.dispatchmultiple);
app.post("/contact-us",sendEmail.contactUs);
app.post("/complaints",sendEmail.complaints);
app.post("/becomeadriver",sendEmail.becomeadriver);
app.get("/dispatch-count",bookingController.dispatchcount)

app.use(
  '/graphql',
  graphqlHttp({
    schema: graphQlSchema,
    rootValue: graphQlResolvers,
    graphiql: true
  })
);

// mongoose.connect(`mongodb+srv://${process.env.MONGO_USER}:${process.env.MONGO_PASSWORD}@cluster0-uejge.mongodb.net/${process.env.MONGO_DB}?retryWrites=true`,{ useNewUrlParser: true }).then(() => {

// })
// .catch(err => {
//     console.log(err);
// });

mongoose.connect('mongodb://127.0.0.1:27017/events').then(() => {
  console.log("database connected")
})
.catch(err => {
    console.log(err);
});

var server = app.listen(process.env.PORT || 8000, function () {
  var port = server.address().port;
  console.log("Express is working on port " + port);
});
